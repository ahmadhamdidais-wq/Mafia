// Shared contract between server and web client.
// Nothing secret lives here: these are types and public rules only.

export type Role = 'MAFIA' | 'CITIZEN' | 'DOCTOR' | 'DETECTIVE';
export type Team = 'MAFIA' | 'TOWN';
export type Winner = Team;

export type Phase =
  | 'LOBBY'
  | 'ROLE_REVEAL'
  | 'NIGHT'
  | 'DAY'
  | 'DISCUSSION'
  | 'VOTING'
  | 'RESULT'
  | 'GAME_OVER';

export const LIMITS = {
  MIN_PLAYERS: 5,
  MAX_PLAYERS: 15,
  NAME_MIN: 2,
  NAME_MAX: 16,
  CHAT_MAX: 300,
  RECONNECT_GRACE_MS: 60_000,
  HOST_MIGRATION_MS: 15_000,
} as const;

export const ROOM_CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export const ROOM_CODE_LENGTH = 5;
export const ROOM_CODE_REGEX = /^[A-HJ-NP-Z2-9]{5}$/;

export interface RoomSettings {
  nightSeconds: number;
  discussionSeconds: number;
  votingSeconds: number;
  revealRoleOnDeath: boolean;
}

export const DEFAULT_SETTINGS: RoomSettings = {
  nightSeconds: 30,
  discussionSeconds: 120,
  votingSeconds: 30,
  revealRoleOnDeath: true,
};

/** Non-configurable phase lengths (seconds). */
export const FIXED_PHASE_SECONDS = { ROLE_REVEAL: 25, DAY: 8, RESULT: 8 } as const;

export function phaseSeconds(phase: Phase, s: RoomSettings): number {
  switch (phase) {
    case 'ROLE_REVEAL':
      return FIXED_PHASE_SECONDS.ROLE_REVEAL;
    case 'NIGHT':
      return s.nightSeconds;
    case 'DAY':
      return FIXED_PHASE_SECONDS.DAY;
    case 'DISCUSSION':
      return s.discussionSeconds;
    case 'VOTING':
      return s.votingSeconds;
    case 'RESULT':
      return FIXED_PHASE_SECONDS.RESULT;
    default:
      return 0;
  }
}

export const SETTINGS_BOUNDS = {
  nightSeconds: [15, 90],
  discussionSeconds: [30, 300],
  votingSeconds: [15, 90],
} as const;

export function teamOf(role: Role): Team {
  return role === 'MAFIA' ? 'MAFIA' : 'TOWN';
}

export type DeathCause = 'MAFIA' | 'VOTE' | 'LEFT';

export interface PlayerView {
  id: string;
  name: string;
  avatar: string;
  isHost: boolean;
  ready: boolean;
  connected: boolean;
  alive: boolean;
  /** Only present when this viewer is allowed to know it. */
  role?: Role;
  deathCause?: DeathCause;
}

export interface VoteTallyEntry {
  targetId: string;
  count: number;
}

export interface Investigation {
  round: number;
  targetId: string;
  isMafia: boolean;
}

export interface GameView {
  roomCode: string;
  hostId: string;
  phase: Phase;
  round: number;
  /** Server epoch ms when the current phase ends (null = no timer). */
  endsAt: number | null;
  serverNow: number;
  settings: RoomSettings;
  players: PlayerView[];
  minPlayers: number;
  maxPlayers: number;
  me: {
    id: string;
    role: Role | null;
    alive: boolean;
    isHost: boolean;
    ackedRole: boolean;
  };
  /** Mafia only: ids of fellow mafia members. */
  mafiaTeam?: string[];
  night?: {
    canAct: boolean;
    myTarget: string | null;
    locked: boolean;
    /** Mafia only: what each teammate picked. */
    mafiaVotes?: { voterId: string; targetId: string }[];
    /** Doctor only: cannot protect the same player two nights in a row. */
    blockedTargetId?: string | null;
  };
  discussion?: { skipCount: number; eligible: number; iSkipped: boolean };
  voting?: { votedCount: number; eligible: number; myVote: string | null };
  lastNight?: { victimId: string | null; strange: boolean };
  lastVote?: {
    tally: VoteTallyEntry[];
    skipCount: number;
    eliminatedId: string | null;
  };
  /** Detective only. */
  investigations?: Investigation[];
  ackCount?: { acked: number; total: number };
  winner?: Winner;
  finalRoles?: { id: string; role: Role }[];
}

export type ChatChannel = 'LOBBY' | 'PUBLIC' | 'MAFIA' | 'DEAD';

export interface ChatMessage {
  id: string;
  channel: ChatChannel;
  senderId: string | null; // null = system
  senderName: string;
  text: string;
  at: number;
}

export interface AckResult {
  ok: boolean;
  error?: string;
}

export type Ack = (res: AckResult) => void;

export interface PhaseNotice {
  phase: Phase;
  round: number;
}

export interface ServerToClientEvents {
  'room:state': (view: GameView) => void;
  'game:phase': (notice: PhaseNotice) => void;
  'chat:message': (msg: ChatMessage) => void;
  'chat:history': (msgs: ChatMessage[]) => void;
  'game:end': (payload: { winner: Winner }) => void;
  'room:kicked': (payload: { reason: string }) => void;
}

export interface ClientToServerEvents {
  'room:join': (ack?: Ack) => void;
  'player:reconnect': (ack?: Ack) => void;
  'room:leave': (ack?: Ack) => void;
  'player:ready': (payload: { ready: boolean }, ack?: Ack) => void;
  'room:settings': (payload: Partial<RoomSettings>, ack?: Ack) => void;
  'game:start': (ack?: Ack) => void;
  'role:ack': (ack?: Ack) => void;
  'night:action': (payload: { targetId: string }, ack?: Ack) => void;
  'discussion:skip': (ack?: Ack) => void;
  'vote:cast': (payload: { targetId: string | 'SKIP' }, ack?: Ack) => void;
  'chat:message': (payload: { channel: ChatChannel; text: string }, ack?: Ack) => void;
  'game:replay': (ack?: Ack) => void;
  'room:lobby': (ack?: Ack) => void;
}

export interface SocketAuth {
  roomCode: string;
  userToken: string;
}

// REST payloads
export interface JoinResponse {
  roomCode: string;
  inviteUrl: string;
  userId: string;
  userToken: string;
  name: string;
}

export interface RoomInfo {
  code: string;
  playerCount: number;
  maxPlayers: number;
  phase: Phase;
  joinable: boolean;
}

export interface AchievementDef {
  key: string;
  icon: string;
  title: string;
  description: string;
}

export const ACHIEVEMENTS: AchievementDef[] = [
  { key: 'DETECTIVE_5', icon: '🕵️', title: 'المحقق', description: 'اكتشف المافيا 5 مرات.' },
  { key: 'MAFIA_PRO', icon: '🔪', title: 'المافيا المحترف', description: 'افز 10 مباريات كمافيا.' },
  { key: 'DOCTOR_SAVE', icon: '❤️', title: 'الطبيب', description: 'أنقذ لاعبًا من الموت.' },
  { key: 'DECEIVER', icon: '🎭', title: 'المخادع', description: 'افز كمافيا دون أن يصوّت ضدك أحد.' },
  { key: 'SURVIVOR', icon: '☠️', title: 'الناجي', description: 'كن آخر مواطن حي عند نهاية المباراة.' },
];

export interface PlayerProfile {
  id: string;
  name: string;
  xp: number;
  level: number;
  stats: {
    gamesPlayed: number;
    wins: number;
    losses: number;
    mafiaWins: number;
    citizenWins: number;
    detectiveWins: number;
    doctorSaves: number;
    detectiveFinds: number;
    playersEliminated: number;
  };
  achievements: { key: string; unlockedAt: string }[];
}

export function levelFromXp(xp: number): number {
  return Math.floor(Math.sqrt(Math.max(0, xp) / 100)) + 1;
}
