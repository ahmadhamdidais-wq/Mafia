'use client';

/**
 * All sound effects are synthesised with the Web Audio API — no audio files to load,
 * nothing to slow a phone down. Every effect is a no-op when sound is turned off.
 */
class SoundEngine {
  enabled = true;
  private ctx: AudioContext | null = null;

  unlock() {
    if (typeof window === 'undefined') return;
    if (!this.ctx) {
      const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume();
  }

  private get ready(): AudioContext | null {
    if (!this.enabled) return null;
    this.unlock();
    return this.ctx && this.ctx.state === 'running' ? this.ctx : null;
  }

  private tone(freq: number, start: number, dur: number, type: OscillatorType = 'sine', gain = 0.15, endFreq?: number) {
    const ctx = this.ready;
    if (!ctx) return;
    const t = ctx.currentTime + start;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (endFreq) osc.frequency.exponentialRampToValueAtTime(endFreq, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g).connect(ctx.destination);
    osc.start(t);
    osc.stop(t + dur + 0.05);
  }

  private noise(start: number, dur: number, gain = 0.2, lowpass = 800) {
    const ctx = this.ready;
    if (!ctx) return;
    const t = ctx.currentTime + start;
    const buf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * dur), ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = lowpass;
    const g = ctx.createGain();
    g.gain.value = gain;
    src.connect(filter).connect(g).connect(ctx.destination);
    src.start(t);
  }

  night() {
    this.tone(110, 0, 2.2, 'sine', 0.12, 82);
    this.tone(165, 0.15, 2, 'triangle', 0.05, 123);
    this.noise(0, 1.8, 0.05, 400);
  }
  heartbeat() {
    this.tone(60, 0, 0.15, 'sine', 0.35, 40);
    this.tone(55, 0.22, 0.18, 'sine', 0.28, 38);
  }
  vote() {
    this.tone(520, 0, 0.08, 'square', 0.06);
    this.tone(780, 0.07, 0.12, 'square', 0.05);
  }
  kill() {
    this.noise(0, 0.5, 0.35, 1200);
    this.tone(90, 0, 0.9, 'sawtooth', 0.12, 40);
  }
  reveal() {
    [392, 494, 587].forEach((f, i) => this.tone(f, i * 0.09, 0.5, 'triangle', 0.08));
  }
  victory() {
    [523, 659, 784, 1047].forEach((f, i) => this.tone(f, i * 0.12, 0.6, 'triangle', 0.1));
  }
  defeat() {
    [392, 349, 311, 262].forEach((f, i) => this.tone(f, i * 0.22, 0.7, 'sine', 0.1));
  }
  tick() {
    this.tone(1200, 0, 0.03, 'square', 0.03);
  }
}

export const sound = new SoundEngine();
