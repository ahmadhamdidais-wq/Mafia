import type { JoinResponse, PlayerProfile, RoomInfo } from '@mafia/shared';

const BASE = process.env.NEXT_PUBLIC_SERVER_URL ?? '';

export class ApiError extends Error {
  constructor(message: string, readonly status: number) {
    super(message);
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${BASE}/api${path}`, {
      ...init,
      headers: { 'Content-Type': 'application/json', ...init?.headers },
    });
  } catch {
    throw new ApiError('تعذر الاتصال بالخادم. تحقق من الإنترنت وحاول مجددًا.', 0);
  }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(body.error ?? 'حدث خطأ.', res.status);
  return body as T;
}

export const api = {
  createRoom: (name: string, userToken?: string) =>
    request<JoinResponse>('/rooms', { method: 'POST', body: JSON.stringify({ name, userToken }) }),
  joinRoom: (code: string, name: string, userToken?: string) =>
    request<JoinResponse>('/rooms/join', { method: 'POST', body: JSON.stringify({ code, name, userToken }) }),
  room: (code: string) => request<RoomInfo>(`/rooms/${encodeURIComponent(code)}`),
  player: (id: string) => request<PlayerProfile>(`/player/${encodeURIComponent(id)}`),
};
