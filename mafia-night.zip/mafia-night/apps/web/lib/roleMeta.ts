import type { Role } from '@mafia/shared';

/** Visual identity of each role. Text lives in the i18n dictionary. */
export const ROLE_META: Record<Role, { icon: string; accent: string; glow: string }> = {
  MAFIA: { icon: '🔪', accent: '#ff2d3f', glow: 'rgba(255,45,63,.45)' },
  CITIZEN: { icon: '🏠', accent: '#ebe3d1', glow: 'rgba(235,227,209,.25)' },
  DOCTOR: { icon: '💉', accent: '#4fd1a5', glow: 'rgba(79,209,165,.35)' },
  DETECTIVE: { icon: '🕵️', accent: '#c8a24a', glow: 'rgba(200,162,74,.4)' },
};
