'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { io, type Socket } from 'socket.io-client';
import {
  teamOf,
  type AckResult,
  type ChatChannel,
  type ChatMessage,
  type ClientToServerEvents,
  type GameView,
  type RoomSettings,
  type ServerToClientEvents,
} from '@mafia/shared';
import { sound } from './sound';

type GameSocket = Socket<ServerToClientEvents, ClientToServerEvents>;
export type ConnStatus = 'connecting' | 'connected' | 'reconnecting' | 'kicked' | 'denied';

const SOCKET_URL = process.env.NEXT_PUBLIC_SERVER_URL || undefined; // same origin by default

export function useGame(roomCode: string, userToken: string | null) {
  const socketRef = useRef<GameSocket | null>(null);
  const [view, setView] = useState<GameView | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [status, setStatus] = useState<ConnStatus>('connecting');
  const [statusDetail, setStatusDetail] = useState<string | null>(null);
  /** serverNow - clientNow, so timers stay correct even if the phone clock is off. */
  const [clockOffset, setClockOffset] = useState(0);
  const prevView = useRef<GameView | null>(null);

  useEffect(() => {
    if (!userToken) return;
    const socket: GameSocket = io(SOCKET_URL as string, {
      auth: { roomCode, userToken },
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 800,
      reconnectionDelayMax: 4000,
    });
    socketRef.current = socket;

    socket.on('connect', () => {
      setStatus('connected');
      socket.emit('room:join');
    });
    socket.on('disconnect', (reason) => {
      if (reason === 'io server disconnect') return; // kicked or denied — handled elsewhere
      setStatus('reconnecting');
    });
    socket.on('connect_error', (err) => {
      if (['NOT_A_MEMBER', 'ROOM_NOT_FOUND', 'UNAUTHORIZED'].includes(err.message)) {
        setStatus('denied');
        setStatusDetail(err.message);
        socket.disconnect();
      } else {
        setStatus('reconnecting');
      }
    });
    socket.on('room:state', (v) => {
      setClockOffset(v.serverNow - Date.now());
      setView(v);
    });
    socket.on('chat:history', (msgs) => setMessages(msgs));
    socket.on('chat:message', (m) => setMessages((prev) => [...prev.slice(-200), m]));
    socket.on('room:kicked', ({ reason }) => {
      setStatus('kicked');
      setStatusDetail(reason);
    });

    // Phones suspend sockets in the background; reconnect as soon as the tab is visible again.
    const onVisible = () => {
      if (document.visibilityState === 'visible' && !socket.connected && socket.active) socket.connect();
    };
    document.addEventListener('visibilitychange', onVisible);

    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      socket.removeAllListeners();
      socket.disconnect();
      socketRef.current = null;
    };
  }, [roomCode, userToken]);

  // Sound cues on phase transitions.
  useEffect(() => {
    const prev = prevView.current;
    prevView.current = view;
    if (!view || !prev || prev.phase === view.phase) return;
    switch (view.phase) {
      case 'ROLE_REVEAL':
        sound.reveal();
        break;
      case 'NIGHT':
        sound.night();
        break;
      case 'DAY':
        view.lastNight?.victimId ? sound.kill() : sound.reveal();
        break;
      case 'RESULT':
        view.lastVote?.eliminatedId ? sound.kill() : sound.reveal();
        break;
      case 'GAME_OVER':
        if (view.winner && view.me.role) teamOf(view.me.role) === view.winner ? sound.victory() : sound.defeat();
        break;
    }
  }, [view]);

  const emit = useCallback(
    <E extends keyof ClientToServerEvents>(event: E, ...args: unknown[]): Promise<AckResult> =>
      new Promise((resolve) => {
        const s = socketRef.current;
        if (!s?.connected) return resolve({ ok: false, error: 'لا يوجد اتصال الآن.' });
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (s.timeout(6000) as any).emit(event, ...args, (err: unknown, res: AckResult) =>
          resolve(err ? { ok: false, error: 'انتهت مهلة الطلب.' } : res),
        );
      }),
    [],
  );

  const actions = {
    ready: (ready: boolean) => emit('player:ready', { ready }),
    start: () => emit('game:start'),
    settings: (patch: Partial<RoomSettings>) => emit('room:settings', patch),
    ackRole: () => emit('role:ack'),
    nightAction: (targetId: string) => emit('night:action', { targetId }),
    skipDiscussion: () => emit('discussion:skip'),
    vote: (targetId: string) => emit('vote:cast', { targetId }),
    chat: (channel: ChatChannel, text: string) => emit('chat:message', { channel, text }),
    replay: () => emit('game:replay'),
    lobby: () => emit('room:lobby'),
    leave: () => emit('room:leave'),
  };

  return { view, messages, status, statusDetail, clockOffset, actions };
}

export type GameActions = ReturnType<typeof useGame>['actions'];
