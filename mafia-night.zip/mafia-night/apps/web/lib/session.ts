'use client';
import type { JoinResponse } from '@mafia/shared';

/** Guest identity kept on this device. The token is a secret only the server can verify. */
export interface Session {
  userId: string;
  userToken: string;
  name: string;
}

const KEY = 'mafia-night:session';

export function loadSession(): Session | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as Session;
    return s?.userId && s?.userToken ? s : null;
  } catch {
    return null;
  }
}

export function saveSession(r: JoinResponse) {
  try {
    localStorage.setItem(KEY, JSON.stringify({ userId: r.userId, userToken: r.userToken, name: r.name }));
  } catch {
    /* private mode — session lasts for this tab only */
  }
}
