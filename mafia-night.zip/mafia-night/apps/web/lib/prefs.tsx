'use client';
import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { sound } from './sound';

interface Prefs {
  soundOn: boolean;
  setSoundOn: (v: boolean) => void;
}
const PrefsContext = createContext<Prefs>({ soundOn: true, setSoundOn: () => {} });
const KEY = 'mafia-night:sound';

export function PrefsProvider({ children }: { children: ReactNode }) {
  const [soundOn, setState] = useState(true);
  useEffect(() => {
    const v = localStorage.getItem(KEY) !== 'off';
    setState(v);
    sound.enabled = v;
    // Browsers only allow audio after a user gesture.
    const unlock = () => sound.unlock();
    window.addEventListener('pointerdown', unlock, { once: true });
    return () => window.removeEventListener('pointerdown', unlock);
  }, []);
  const setSoundOn = useCallback((v: boolean) => {
    setState(v);
    sound.enabled = v;
    try {
      localStorage.setItem(KEY, v ? 'on' : 'off');
    } catch {}
  }, []);
  return <PrefsContext.Provider value={{ soundOn, setSoundOn }}>{children}</PrefsContext.Provider>;
}

export const usePrefs = () => useContext(PrefsContext);
