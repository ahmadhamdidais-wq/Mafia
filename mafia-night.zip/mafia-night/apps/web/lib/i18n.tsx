'use client';
import { createContext, useContext, type ReactNode } from 'react';
import { ar, type Messages } from '@/messages/ar';

export type Locale = 'ar' | 'en' | 'he';

/** Add `en` / `he` dictionaries (same shape as `ar`) to enable those languages. */
const dictionaries: Record<Locale, Messages> = { ar, en: ar, he: ar };
export const LOCALE_DIR: Record<Locale, 'rtl' | 'ltr'> = { ar: 'rtl', he: 'rtl', en: 'ltr' };
export const AVAILABLE_LOCALES: Locale[] = ['ar'];

const I18nContext = createContext<Messages>(ar);

export function I18nProvider({ locale = 'ar', children }: { locale?: Locale; children: ReactNode }) {
  return <I18nContext.Provider value={dictionaries[locale]}>{children}</I18nContext.Provider>;
}

export const useT = () => useContext(I18nContext);
