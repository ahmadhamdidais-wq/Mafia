'use client';
import { ACHIEVEMENTS } from '@mafia/shared';
import { useT } from '@/lib/i18n';

export function AchievementPanel({ unlocked }: { unlocked: { key: string; unlockedAt: string }[] }) {
  const t = useT();
  const have = new Map(unlocked.map((a) => [a.key, a.unlockedAt]));
  return (
    <section>
      <h2 className="mb-3 font-ruqaa text-2xl text-gold">{t.profile.achievements}</h2>
      <ul className="space-y-2">
        {ACHIEVEMENTS.map((a) => {
          const on = have.has(a.key);
          return (
            <li key={a.key} className={`flex items-center gap-3 rounded-[3px] border px-3 py-3 ${on ? 'border-gold/50 bg-gold/5' : 'border-white/5 opacity-50'}`}>
              <span className={`text-3xl ${on ? '' : 'grayscale'}`}>{a.icon}</span>
              <span>
                <span className="block font-bold">{a.title}</span>
                <span className="block text-sm text-smoke">{a.description}</span>
              </span>
              {on && <span className="ms-auto text-gold">✓</span>}
            </li>
          );
        })}
      </ul>
    </section>
  );
}
