'use client';
import { motion } from 'framer-motion';
import { useState } from 'react';
import type { GameView } from '@mafia/shared';
import { PlayerCard } from './PlayerCard';
import { InvestigationLog } from './InvestigationLog';
import { useT } from '@/lib/i18n';
import type { GameActions } from '@/lib/useGame';

export function NightScreen({ view, actions }: { view: GameView; actions: GameActions }) {
  const t = useT();
  const [error, setError] = useState<string | null>(null);
  const role = view.me.role;
  const night = view.night;
  const alive = view.players.filter((p) => p.alive);
  const mafiaTeam = new Set(view.mafiaTeam ?? []);
  const nameOf = (id: string) => view.players.find((p) => p.id === id)?.name ?? '';

  const prompt = !view.me.alive
    ? t.night.dead
    : role === 'MAFIA'
      ? t.night.mafia
      : role === 'DOCTOR'
        ? t.night.doctor
        : role === 'DETECTIVE'
          ? t.night.detective
          : t.night.citizen;

  const choose = async (id: string) => {
    const res = await actions.nightAction(id);
    setError(res.ok ? null : (res.error ?? null));
  };

  const disabledFor = (id: string) => {
    if (!night?.canAct || night.locked) return true;
    if (role === 'MAFIA') return mafiaTeam.has(id);
    if (role === 'DETECTIVE') return id === view.me.id;
    if (role === 'DOCTOR') return id === night.blockedTargetId;
    return true;
  };

  return (
    <div className="space-y-5">
      <motion.div className="flex flex-col items-center gap-2 pt-2 text-center" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1.2 }}>
        <motion.span
          className="text-6xl"
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 1.4, ease: 'easeOut' }}
          style={{ filter: 'drop-shadow(0 0 24px rgba(159,179,209,.6))' }}
        >
          🌙
        </motion.span>
        <h2 className="font-ruqaa text-4xl text-moon">{t.night.title}</h2>
        <p className="text-lg">{prompt}</p>
        {night?.canAct && role !== 'CITIZEN' && night.locked && <p className="text-sm text-gold">{t.night.locked}</p>}
        {!night?.canAct && view.me.alive && <p className="max-w-xs text-sm text-smoke">{t.night.citizenSub}</p>}
      </motion.div>

      {night?.canAct && (
        <div className="grid gap-2 sm:grid-cols-2">
          {alive.map((p) => {
            const teamPicks = (night.mafiaVotes ?? []).filter((v) => v.targetId === p.id);
            return (
              <PlayerCard
                key={p.id}
                player={p}
                isMe={p.id === view.me.id}
                selected={night.myTarget === p.id}
                disabled={disabledFor(p.id)}
                teammate={role === 'MAFIA' && mafiaTeam.has(p.id)}
                onSelect={() => choose(p.id)}
                badge={
                  <span className="flex flex-col items-end gap-0.5 text-xs">
                    {teamPicks.length > 0 && <span className="rounded-sm bg-neon/20 px-1.5 text-neon">🔪 {teamPicks.length}</span>}
                    {role === 'DOCTOR' && p.id === night.blockedTargetId && <span className="text-smoke">{t.night.noRepeat}</span>}
                  </span>
                }
              />
            );
          })}
        </div>
      )}

      {role === 'MAFIA' && night?.mafiaVotes && night.mafiaVotes.length > 0 && (
        <p className="text-center text-sm text-neon/80">
          {t.night.teamPicks}: {night.mafiaVotes.map((v) => `${nameOf(v.voterId)} ← ${nameOf(v.targetId)}`).join('، ')}
        </p>
      )}
      {role === 'DETECTIVE' && <InvestigationLog view={view} />}
      {error && <p className="text-center text-sm text-neon">{error}</p>}
    </div>
  );
}
