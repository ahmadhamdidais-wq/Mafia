'use client';
import { AnimatePresence, motion } from 'framer-motion';
import type { ConnStatus } from '@/lib/useGame';
import { useT } from '@/lib/i18n';

export function ConnectionBanner({ status }: { status: ConnStatus }) {
  const t = useT();
  const show = status === 'reconnecting';
  return (
    <AnimatePresence>
      {show && (
        <motion.div
          role="status"
          initial={{ y: -40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -40, opacity: 0 }}
          className="fixed inset-x-0 top-0 z-50 flex items-center justify-center gap-2 bg-blood/95 px-4 py-2 text-sm font-bold"
        >
          <span className="h-3 w-3 animate-spin rounded-full border-2 border-bone border-t-transparent" />
          {t.status.lost} — {t.status.reconnecting}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
