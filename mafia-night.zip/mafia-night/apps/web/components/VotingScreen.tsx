'use client';
import { motion } from 'framer-motion';
import { useState } from 'react';
import type { GameView } from '@mafia/shared';
import { PlayerCard } from './PlayerCard';
import { Button } from './Button';
import { useT } from '@/lib/i18n';
import { sound } from '@/lib/sound';
import type { GameActions } from '@/lib/useGame';

export function VotingScreen({ view, actions }: { view: GameView; actions: GameActions }) {
  const t = useT();
  const [pending, setPending] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const v = view.voting;
  const myVote = v?.myVote ?? null;
  const canVote = view.me.alive && !myVote;
  const candidates = view.players.filter((p) => p.alive && p.id !== view.me.id);

  const confirm = async () => {
    if (!pending) return;
    const res = await actions.vote(pending);
    if (res.ok) {
      sound.vote();
      setError(null);
    } else setError(res.error ?? null);
  };

  return (
    <div className="space-y-4">
      <header className="text-center">
        <motion.h2 initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="font-ruqaa text-4xl text-neon">
          {t.voting.title}
        </motion.h2>
        <p className="text-lg">{t.voting.question}</p>
        <p className="text-xs text-smoke">{t.voting.secret}</p>
      </header>

      {myVote ? (
        <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="deco-frame rounded-[3px] bg-black/70 p-5 text-center">
          <p className="text-2xl">🗳️</p>
          <p className="font-bold text-gold">{t.voting.done}</p>
          <p className="text-sm text-smoke">{myVote === 'SKIP' ? t.voting.abstain : view.players.find((p) => p.id === myVote)?.name}</p>
        </motion.div>
      ) : view.me.alive ? (
        <>
          <div className="grid gap-2 sm:grid-cols-2">
            {candidates.map((p) => (
              <PlayerCard key={p.id} player={p} selected={pending === p.id} onSelect={() => setPending(p.id)} />
            ))}
            <button
              type="button"
              onClick={() => setPending('SKIP')}
              className={`min-h-[72px] rounded-[3px] border px-3 text-smoke ${pending === 'SKIP' ? 'border-gold text-gold' : 'border-dashed border-white/15'}`}
            >
              🤐 {t.voting.abstain}
            </button>
          </div>
          <Button className="w-full" disabled={!pending || !canVote} onClick={confirm}>
            {t.voting.cast}
            {pending && pending !== 'SKIP' ? `: ${view.players.find((p) => p.id === pending)?.name}` : ''}
          </Button>
        </>
      ) : null}

      {v && <p className="text-center text-sm tabular-nums text-smoke">{t.voting.progress(v.votedCount, v.eligible)}</p>}
      {error && <p className="text-center text-sm text-neon">{error}</p>}
    </div>
  );
}
