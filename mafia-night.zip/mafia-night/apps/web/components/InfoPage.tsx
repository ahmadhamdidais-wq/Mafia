import Link from 'next/link';
import type { ReactNode } from 'react';
import { CityBackdrop } from './CityBackdrop';

export function InfoPage({ title, children }: { title: string; children: ReactNode }) {
  return (
    <main className="relative min-h-dvh px-5 pb-16 pt-8">
      <CityBackdrop rain={false} />
      <div className="mx-auto max-w-2xl">
        <Link href="/" className="text-sm text-smoke hover:text-gold">
          → رجوع
        </Link>
        <h1 className="mb-6 mt-3 font-ruqaa text-5xl text-gold">{title}</h1>
        <div className="space-y-4 leading-loose">{children}</div>
      </div>
    </main>
  );
}
