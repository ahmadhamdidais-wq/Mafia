'use client';
import { motion, type HTMLMotionProps } from 'framer-motion';
import { forwardRef } from 'react';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';

const styles: Record<Variant, string> = {
  primary:
    'bg-blood text-bone deco-frame hover:bg-[#82121a] active:bg-[#5a0b10] shadow-[0_8px_30px_-12px_rgba(255,45,63,.6)]',
  secondary: 'bg-black/60 text-gold border border-gold/50 hover:border-gold hover:bg-black/80 backdrop-blur-sm',
  ghost: 'bg-transparent text-bone/80 hover:text-bone border border-white/10 hover:border-white/25',
  danger: 'bg-transparent text-neon border border-neon/50 hover:bg-neon/10',
};

export interface ButtonProps extends HTMLMotionProps<'button'> {
  variant?: Variant;
  size?: 'md' | 'lg';
  loading?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'primary', size = 'lg', loading, disabled, className = '', children, ...rest },
  ref,
) {
  return (
    <motion.button
      ref={ref}
      whileTap={disabled || loading ? undefined : { scale: 0.97 }}
      disabled={disabled || loading}
      className={`relative inline-flex select-none items-center justify-center gap-2 rounded-[3px] font-bold transition-colors disabled:cursor-not-allowed disabled:opacity-40 ${
        size === 'lg' ? 'min-h-[56px] px-6 text-lg' : 'min-h-[44px] px-4 text-base'
      } ${styles[variant]} ${className}`}
      {...rest}
    >
      {loading ? <span className="h-5 w-5 animate-spin rounded-full border-2 border-current border-t-transparent" /> : children}
    </motion.button>
  );
});
