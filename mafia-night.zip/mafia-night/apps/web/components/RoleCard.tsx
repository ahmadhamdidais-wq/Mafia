'use client';
import { motion } from 'framer-motion';
import { useState } from 'react';
import type { GameView } from '@mafia/shared';
import { Button } from './Button';
import { ROLE_META } from '@/lib/roleMeta';
import { useT } from '@/lib/i18n';
import { sound } from '@/lib/sound';
import type { GameActions } from '@/lib/useGame';

export function RoleCard({ view, actions }: { view: GameView; actions: GameActions }) {
  const t = useT();
  const [flipped, setFlipped] = useState(view.me.ackedRole);
  const [busy, setBusy] = useState(false);
  const role = view.me.role;
  if (!role) return null;
  const meta = ROLE_META[role];
  const text = t.roles[role];
  const teammates = (view.mafiaTeam ?? []).filter((id) => id !== view.me.id).map((id) => view.players.find((p) => p.id === id)?.name ?? '');

  const flip = () => {
    if (flipped) return;
    setFlipped(true);
    sound.reveal();
  };

  return (
    <div className="flex flex-col items-center gap-6 py-4">
      <p className="font-ruqaa text-3xl text-gold">{t.roleCard.yourRole}</p>
      <button
        type="button"
        onClick={flip}
        className="relative h-[400px] w-[270px] [perspective:1200px]"
        aria-label={flipped ? text.name : t.roleCard.tapToFlip}
      >
        <motion.div
          className="relative h-full w-full [transform-style:preserve-3d]"
          animate={{ rotateY: flipped ? 180 : 0 }}
          transition={{ duration: 0.8, ease: [0.2, 0.8, 0.2, 1] }}
        >
          {/* Back of the card */}
          <div className="deco-frame absolute inset-0 flex flex-col items-center justify-center gap-4 rounded-md bg-[repeating-linear-gradient(45deg,#16161a_0_10px,#0d0d10_10px_20px)] [backface-visibility:hidden]">
            <span className="neon-sign text-3xl">MAFIA</span>
            <span className="text-5xl">🎩</span>
            <span className="px-6 text-center text-sm text-smoke">{t.roleCard.tapToFlip}</span>
          </div>
          {/* Face of the card */}
          <div
            className="deco-frame absolute inset-0 flex flex-col items-center justify-center gap-4 rounded-md bg-char px-5 text-center [backface-visibility:hidden] [transform:rotateY(180deg)]"
            style={{ boxShadow: `0 0 60px ${meta.glow}` }}
          >
            <span className="text-7xl">{meta.icon}</span>
            <span className="font-deco text-xl tracking-widest" style={{ color: meta.accent }}>
              {role}
            </span>
            <span className="font-ruqaa text-4xl" style={{ color: meta.accent }}>
              {text.name}
            </span>
            <span className="text-sm leading-relaxed text-bone/85">
              <strong className="block text-gold">هدفك:</strong>
              {text.goal}
            </span>
            <span className="text-xs leading-relaxed text-smoke">{text.ability}</span>
          </div>
        </motion.div>
      </button>

      {flipped && teammates.length > 0 && (
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center text-neon">
          {t.roleCard.teammates}: <strong>{teammates.join('، ')}</strong>
        </motion.p>
      )}

      {flipped &&
        (view.me.ackedRole ? (
          <p className="text-smoke">{view.ackCount ? t.roleCard.waiting(view.ackCount.acked, view.ackCount.total) : ''}</p>
        ) : (
          <Button
            className="w-full max-w-[270px]"
            loading={busy}
            onClick={async () => {
              setBusy(true);
              await actions.ackRole();
              setBusy(false);
            }}
          >
            {t.roleCard.gotIt}
          </Button>
        ))}
    </div>
  );
}
