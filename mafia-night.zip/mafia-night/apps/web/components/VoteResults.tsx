'use client';
import { motion } from 'framer-motion';
import type { GameView } from '@mafia/shared';
import { ROLE_META } from '@/lib/roleMeta';
import { useT } from '@/lib/i18n';

export function VoteResults({ view }: { view: GameView }) {
  const t = useT();
  const r = view.lastVote;
  if (!r) return null;
  const max = Math.max(1, ...r.tally.map((x) => x.count), r.skipCount);
  const out = r.eliminatedId ? view.players.find((p) => p.id === r.eliminatedId) : null;

  return (
    <div className="space-y-6 py-2">
      <h2 className="text-center font-ruqaa text-4xl text-gold">{t.result.title}</h2>
      <ul className="space-y-3">
        {r.tally.map((row, i) => {
          const p = view.players.find((x) => x.id === row.targetId);
          return (
            <li key={row.targetId}>
              <div className="mb-1 flex justify-between text-sm">
                <span className="font-bold">{p?.name}</span>
                <span className="text-smoke">{t.result.votes(row.count)}</span>
              </div>
              <div className="h-4 overflow-hidden rounded-sm bg-white/5">
                <motion.div
                  className={`h-full origin-right ${row.targetId === r.eliminatedId ? 'bg-neon' : 'bg-gold/70'}`}
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: row.count / max }}
                  transition={{ delay: 0.3 + i * 0.25, duration: 0.8, ease: 'easeOut' }}
                />
              </div>
            </li>
          );
        })}
        {r.skipCount > 0 && (
          <li className="flex justify-between text-sm text-smoke">
            <span>🤐 {t.result.abstained}</span>
            <span>{t.result.votes(r.skipCount)}</span>
          </li>
        )}
      </ul>
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 + r.tally.length * 0.25 + 0.6 }}
        className="deco-frame rounded-[3px] bg-black/70 p-5 text-center"
      >
        {out ? (
          <>
            <p className="text-xl">{t.result.out(out.name)}</p>
            {out.role ? (
              <p className="mt-1" style={{ color: ROLE_META[out.role].accent }}>
                {t.day.wasRole}: {ROLE_META[out.role].icon} {t.roles[out.role].name}
              </p>
            ) : (
              <p className="mt-1 text-sm text-smoke">{t.day.roleHidden}</p>
            )}
          </>
        ) : (
          <p className="text-lg text-smoke">{t.result.noOne}</p>
        )}
      </motion.div>
    </div>
  );
}
