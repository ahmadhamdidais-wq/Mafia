'use client';
import type { InputHTMLAttributes } from 'react';

export function TextField({ label, ...rest }: { label: string } & InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm text-smoke">{label}</span>
      <input
        className="h-14 w-full rounded-[3px] border border-white/15 bg-black/70 px-4 text-lg text-bone placeholder:text-white/25 focus:border-gold focus:outline-none"
        {...rest}
      />
    </label>
  );
}
