'use client';
import { SETTINGS_BOUNDS, type RoomSettings } from '@mafia/shared';
import { Modal } from './Modal';
import { usePrefs } from '@/lib/prefs';
import { useT } from '@/lib/i18n';

interface Props {
  open: boolean;
  onClose: () => void;
  room?: { settings: RoomSettings; editable: boolean; onChange: (patch: Partial<RoomSettings>) => void };
}

export function Settings({ open, onClose, room }: Props) {
  const t = useT();
  const { soundOn, setSoundOn } = usePrefs();

  const slider = (key: keyof typeof SETTINGS_BOUNDS, label: string) => {
    if (!room) return null;
    const [min, max] = SETTINGS_BOUNDS[key];
    return (
      <label className="block">
        <span className="flex justify-between text-sm">
          <span>{label}</span>
          <span className="tabular-nums text-gold">
            {room.settings[key]} {t.settings.seconds}
          </span>
        </span>
        <input
          type="range"
          min={min}
          max={max}
          step={5}
          disabled={!room.editable}
          value={room.settings[key]}
          onChange={(e) => room.onChange({ [key]: Number(e.target.value) })}
          className="mt-1 w-full accent-[#c8a24a]"
        />
      </label>
    );
  };

  return (
    <Modal open={open} onClose={onClose} title={t.settings.title}>
      <div className="space-y-5">
        <Toggle label={t.settings.sound} value={soundOn} onChange={setSoundOn} />
        {room && (
          <div className="space-y-4 border-t border-white/10 pt-4">
            <p className="text-sm text-smoke">{t.settings.room}</p>
            {slider('nightSeconds', t.settings.night)}
            {slider('discussionSeconds', t.settings.discussion)}
            {slider('votingSeconds', t.settings.voting)}
            <Toggle
              label={t.settings.reveal}
              value={room.settings.revealRoleOnDeath}
              disabled={!room.editable}
              onChange={(v) => room.onChange({ revealRoleOnDeath: v })}
            />
          </div>
        )}
        <button onClick={onClose} className="h-12 w-full rounded-[3px] border border-white/15 text-bone/80 hover:border-white/30">
          {t.settings.close}
        </button>
      </div>
    </Modal>
  );
}

function Toggle({ label, value, onChange, disabled }: { label: string; value: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={value}
      disabled={disabled}
      onClick={() => onChange(!value)}
      className="flex w-full items-center justify-between gap-4 text-start disabled:opacity-50"
    >
      <span>{label}</span>
      <span className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${value ? 'bg-blood' : 'bg-steel'}`}>
        <span className={`absolute top-1 h-5 w-5 rounded-full bg-bone transition-all ${value ? 'start-6' : 'start-1'}`} />
      </span>
    </button>
  );
}
