'use client';
import { useEffect, useRef, useState } from 'react';
import { sound } from '@/lib/sound';

/** Displays the server-owned deadline. The client never decides when a phase ends. */
export function Timer({ endsAt, total, offset, heartbeat = false }: { endsAt: number | null; total: number; offset: number; heartbeat?: boolean }) {
  const [now, setNow] = useState(() => Date.now() + offset);
  const lastBeat = useRef<number | null>(null);

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now() + offset), 250);
    return () => clearInterval(id);
  }, [offset]);

  const remaining = endsAt ? Math.max(0, Math.ceil((endsAt - now) / 1000)) : 0;
  const pct = endsAt && total > 0 ? Math.min(1, Math.max(0, (endsAt - now) / (total * 1000))) : 0;
  const urgent = remaining <= 10 && remaining > 0;

  useEffect(() => {
    if (!heartbeat || !urgent || lastBeat.current === remaining) return;
    lastBeat.current = remaining;
    sound.heartbeat();
  }, [heartbeat, urgent, remaining]);

  if (!endsAt) return null;
  const r = 22;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative h-14 w-14" role="timer" aria-label={`${remaining} ثانية`}>
      <svg viewBox="0 0 52 52" className="h-full w-full -rotate-90">
        <circle cx="26" cy="26" r={r} fill="rgba(0,0,0,.6)" stroke="rgba(255,255,255,.08)" strokeWidth="3" />
        <circle
          cx="26"
          cy="26"
          r={r}
          fill="none"
          stroke={urgent ? '#ff2d3f' : '#c8a24a'}
          strokeWidth="3"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - pct)}
          style={{ transition: 'stroke-dashoffset .25s linear, stroke .3s' }}
        />
      </svg>
      <span className={`absolute inset-0 flex items-center justify-center font-bold tabular-nums ${urgent ? 'text-neon' : 'text-bone'}`}>
        {remaining}
      </span>
    </div>
  );
}
