'use client';
import { motion } from 'framer-motion';
import { useState } from 'react';
import type { GameView } from '@mafia/shared';
import { Button } from './Button';
import { PlayerCard } from './PlayerCard';
import { InvestigationLog } from './InvestigationLog';
import { ROLE_META } from '@/lib/roleMeta';
import { useT } from '@/lib/i18n';
import type { GameActions } from '@/lib/useGame';

/** DAY = morning announcement. DISCUSSION = open debate before the vote. */
export function DayScreen({ view, actions }: { view: GameView; actions: GameActions }) {
  return view.phase === 'DAY' ? <Morning view={view} /> : <Discussion view={view} actions={actions} />;
}

function Morning({ view }: { view: GameView }) {
  const t = useT();
  const victim = view.lastNight?.victimId ? view.players.find((p) => p.id === view.lastNight!.victimId) : null;
  const latest = view.investigations?.filter((i) => i.round === view.round).at(-1);
  const suspect = latest ? view.players.find((p) => p.id === latest.targetId) : null;

  return (
    <div className="flex flex-col items-center gap-6 py-6 text-center">
      <motion.div
        className="h-24 w-24 rounded-full"
        style={{ background: 'radial-gradient(circle,#ffd58a 0%,#e8823a 45%,transparent 70%)' }}
        initial={{ y: 80, opacity: 0, scale: 0.6 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        transition={{ duration: 1.6, ease: 'easeOut' }}
      />
      <motion.h2 className="font-ruqaa text-4xl text-gold" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }}>
        {t.day.sunrise}
      </motion.h2>

      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.6, duration: 0.8 }} className="space-y-3">
        {victim ? (
          <>
            <p className="text-xl text-neon">{t.day.body}</p>
            <motion.div
              initial={{ scale: 1.15, filter: 'grayscale(0)' }}
              animate={{ scale: 1, filter: 'grayscale(1)' }}
              transition={{ delay: 2.2, duration: 1.2 }}
              className="deco-frame mx-auto flex w-64 flex-col items-center gap-2 rounded-[3px] bg-black/70 p-5"
            >
              <span className="text-5xl">☠️</span>
              <span className="text-2xl font-bold">{victim.name}</span>
              {victim.role ? (
                <span style={{ color: ROLE_META[victim.role].accent }}>
                  {t.day.wasRole}: {ROLE_META[victim.role].icon} {t.roles[victim.role].name}
                </span>
              ) : (
                <span className="text-sm text-smoke">{t.day.roleHidden}</span>
              )}
            </motion.div>
          </>
        ) : view.lastNight?.strange ? (
          <>
            <p className="text-xl text-moon">{t.day.strange}</p>
            <p className="text-smoke">{t.day.strangeSub}</p>
          </>
        ) : (
          <p className="text-xl">{t.day.calm}</p>
        )}
      </motion.div>

      {latest && suspect && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2.6 }}
          className="w-full max-w-sm rounded-[3px] border border-gold/40 bg-black/70 p-4"
        >
          <p className="text-sm text-gold">🕵️ {t.day.yourFinding}</p>
          <p className="mt-1 text-lg">
            <strong>{suspect.name}</strong> — <span className={latest.isMafia ? 'text-neon' : 'text-emerald-400'}>{latest.isMafia ? t.day.isMafia : t.day.notMafia}</span>
          </p>
        </motion.div>
      )}
    </div>
  );
}

function Discussion({ view, actions }: { view: GameView; actions: GameActions }) {
  const t = useT();
  const [busy, setBusy] = useState(false);
  const d = view.discussion;
  const alive = view.players.filter((p) => p.alive);
  const dead = view.players.filter((p) => !p.alive);
  return (
    <div className="space-y-4">
      <header className="text-center">
        <h2 className="font-ruqaa text-4xl text-gold">{t.discussion.title}</h2>
        <p className="text-smoke">{t.discussion.subtitle}</p>
      </header>
      <div className="grid gap-2 sm:grid-cols-2">
        {[...alive, ...dead].map((p) => (
          <PlayerCard key={p.id} player={p} isMe={p.id === view.me.id} teammate={!!view.mafiaTeam?.includes(p.id) && p.id !== view.me.id} />
        ))}
      </div>
      {view.me.role === 'DETECTIVE' && <InvestigationLog view={view} />}
      {view.me.alive && d && (
        <div className="space-y-1">
          <Button
            className="w-full"
            variant="secondary"
            disabled={d.iSkipped}
            loading={busy}
            onClick={async () => {
              setBusy(true);
              await actions.skipDiscussion();
              setBusy(false);
            }}
          >
            {d.iSkipped ? t.discussion.skipped : `🗳️ ${t.discussion.skip}`}
          </Button>
          <p className="text-center text-xs text-smoke">{t.discussion.skipCount(d.skipCount, d.eligible)}</p>
        </div>
      )}
    </div>
  );
}
