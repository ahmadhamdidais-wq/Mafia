'use client';
import type { GameView } from '@mafia/shared';
import { useT } from '@/lib/i18n';

/** Detective's private case file. Only the detective's client ever receives this data. */
export function InvestigationLog({ view }: { view: GameView }) {
  const t = useT();
  const items = view.investigations ?? [];
  if (!items.length) return null;
  return (
    <section className="rounded-[3px] border border-gold/30 bg-black/60 p-3">
      <h3 className="mb-2 text-sm font-bold text-gold">🕵️ ملف التحقيقات</h3>
      <ul className="space-y-1 text-sm">
        {items.map((i) => (
          <li key={`${i.round}-${i.targetId}`} className="flex justify-between gap-2">
            <span>{view.players.find((p) => p.id === i.targetId)?.name}</span>
            <span className={i.isMafia ? 'text-neon' : 'text-emerald-400'}>{i.isMafia ? `🔴 ${t.roles.MAFIA.name}` : '🟢 بريء'}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}
