'use client';
import { motion } from 'framer-motion';
import type { PlayerView } from '@mafia/shared';
import { ROLE_META } from '@/lib/roleMeta';
import { useT } from '@/lib/i18n';

interface Props {
  player: PlayerView;
  isMe?: boolean;
  selected?: boolean;
  disabled?: boolean;
  onSelect?: () => void;
  badge?: React.ReactNode;
  showReady?: boolean;
  teammate?: boolean;
}

export function PlayerCard({ player, isMe, selected, disabled, onSelect, badge, showReady, teammate }: Props) {
  const t = useT();
  const dead = !player.alive;
  const interactive = !!onSelect && !disabled && !dead;
  const roleMeta = player.role ? ROLE_META[player.role] : null;

  return (
    <motion.button
      type="button"
      layout
      disabled={!interactive}
      onClick={interactive ? onSelect : undefined}
      whileTap={interactive ? { scale: 0.96 } : undefined}
      aria-pressed={selected}
      className={`relative flex min-h-[72px] w-full items-center gap-3 rounded-[3px] border px-3 py-2 text-start transition-colors ${
        selected
          ? 'border-neon bg-blood/40 shadow-neon'
          : teammate
            ? 'border-neon/30 bg-blood/15'
            : 'border-white/10 bg-black/55'
      } ${interactive ? 'cursor-pointer hover:border-gold/60' : 'cursor-default'} ${dead ? 'opacity-45 grayscale' : ''} ${
        disabled && !dead ? 'opacity-50' : ''
      }`}
    >
      <span className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-gold/30 bg-char text-2xl">
        {dead ? '☠️' : player.avatar}
        {!player.connected && <span className="absolute -bottom-0.5 -end-0.5 h-3 w-3 rounded-full border-2 border-black bg-smoke" title={t.lobby.offline} />}
      </span>
      <span className="min-w-0 flex-1">
        <span className={`block truncate font-bold ${dead ? 'line-through decoration-neon/70' : ''}`}>
          {player.name}
          {isMe && <span className="ms-1 text-sm font-normal text-smoke">(أنت)</span>}
        </span>
        <span className="flex flex-wrap items-center gap-x-2 text-xs text-smoke">
          {player.isHost && <span className="text-gold">👑 {t.lobby.host}</span>}
          {showReady && (
            <span className={player.ready ? 'text-emerald-400' : 'text-smoke'}>{player.ready ? `🟢 ${t.lobby.ready}` : `⚪ ${t.lobby.notReady}`}</span>
          )}
          {!showReady && <span>{dead ? `☠️ ${t.discussion.dead}` : `🟢 ${t.discussion.alive}`}</span>}
          {roleMeta && player.role && (
            <span style={{ color: roleMeta.accent }}>
              {roleMeta.icon} {t.roles[player.role].name}
            </span>
          )}
        </span>
      </span>
      {badge}
    </motion.button>
  );
}
