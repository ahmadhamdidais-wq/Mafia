'use client';
import { motion, useReducedMotion } from 'framer-motion';
import { useMemo } from 'react';

const COLORS = ['#c8a24a', '#ff2d3f', '#ebe3d1', '#e8b44a'];

/** Light confetti burst — 36 elements, transform-only animation. */
export function Confetti() {
  const reduce = useReducedMotion();
  const pieces = useMemo(
    () =>
      Array.from({ length: 36 }, (_, i) => ({
        x: (i * 37) % 100,
        delay: (i % 9) * 0.08,
        rotate: (i * 47) % 360,
        drift: ((i * 13) % 40) - 20,
        color: COLORS[i % COLORS.length],
        w: 6 + (i % 3) * 3,
      })),
    [],
  );
  if (reduce) return null;
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-40 overflow-hidden">
      {pieces.map((p, i) => (
        <motion.span
          key={i}
          className="absolute top-0 block"
          style={{ left: `${p.x}%`, width: p.w, height: p.w * 1.6, background: p.color }}
          initial={{ y: -40, opacity: 1, rotate: p.rotate }}
          animate={{ y: '105vh', x: p.drift * 4, rotate: p.rotate + 540, opacity: [1, 1, 0.8] }}
          transition={{ duration: 3.2, delay: p.delay, ease: 'easeIn' }}
        />
      ))}
    </div>
  );
}
