'use client';
import { useState } from 'react';
import type { GameView } from '@mafia/shared';
import { Button } from './Button';
import { PlayerCard } from './PlayerCard';
import { useT } from '@/lib/i18n';
import type { GameActions } from '@/lib/useGame';

export function Lobby({ view, actions, onLeave }: { view: GameView; actions: GameActions; onLeave: () => void }) {
  const t = useT();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const me = view.players.find((p) => p.id === view.me.id);
  const connected = view.players.filter((p) => p.connected);
  const missing = Math.max(0, view.minPlayers - connected.length);
  const allReady = connected.every((p) => p.ready);
  const inviteUrl = typeof window !== 'undefined' ? `${window.location.origin}/room/${view.roomCode}` : '';

  const run = async (fn: () => Promise<{ ok: boolean; error?: string }>) => {
    setBusy(true);
    const res = await fn();
    setBusy(false);
    setError(res.ok ? null : (res.error ?? null));
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(inviteUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {}
  };
  const share = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title: 'MAFIA NIGHT', text: t.created.shareText, url: inviteUrl });
      } catch {}
    } else void copy();
  };

  return (
    <div className="space-y-5">
      <section className="deco-frame rounded-[3px] bg-black/60 p-4 text-center backdrop-blur-sm">
        <p className="text-sm text-smoke">{t.created.code}</p>
        <p className="font-deco text-5xl tracking-[0.25em] text-gold" dir="ltr">
          {view.roomCode}
        </p>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <Button variant="secondary" size="md" onClick={copy}>
            {copied ? `✓ ${t.created.copied}` : `🔗 ${t.created.copy}`}
          </Button>
          <Button variant="secondary" size="md" onClick={share}>
            📤 {t.created.share}
          </Button>
        </div>
      </section>

      <section>
        <div className="mb-2 flex items-baseline justify-between">
          <h2 className="font-ruqaa text-2xl text-gold">{t.lobby.players}</h2>
          <span className="tabular-nums text-smoke" dir="ltr">
            {view.players.length} / {view.maxPlayers}
          </span>
        </div>
        <div className="grid gap-2 sm:grid-cols-2">
          {view.players.map((p) => (
            <PlayerCard key={p.id} player={p} isMe={p.id === view.me.id} showReady />
          ))}
        </div>
      </section>

      <section className="space-y-2">
        {!view.me.isHost && me && (
          <Button className="w-full" variant={me.ready ? 'secondary' : 'primary'} loading={busy} onClick={() => run(() => actions.ready(!me.ready))}>
            {me.ready ? t.lobby.cancelReady : `✋ ${t.lobby.imReady}`}
          </Button>
        )}
        {view.me.isHost ? (
          <>
            <Button className="w-full" disabled={missing > 0 || !allReady} loading={busy} onClick={() => run(actions.start)}>
              🎬 {t.lobby.start}
            </Button>
            <p className="text-center text-sm text-smoke">{missing > 0 ? t.lobby.needMore(missing) : !allReady ? t.lobby.notAllReady : ''}</p>
          </>
        ) : (
          <p className="text-center text-sm text-smoke">{missing > 0 ? t.lobby.needMore(missing) : t.lobby.waitingHost}</p>
        )}
        {error && <p className="text-center text-sm text-neon">{error}</p>}
        <button onClick={onLeave} className="mx-auto block py-2 text-sm text-smoke underline-offset-4 hover:text-neon hover:underline">
          {t.lobby.leave}
        </button>
      </section>
    </div>
  );
}
