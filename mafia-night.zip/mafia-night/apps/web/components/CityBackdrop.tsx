'use client';
import { memo } from 'react';

// Deterministic skyline so server and client render identically.
const BUILDINGS = [
  [0, 210], [48, 150], [92, 250], [150, 180], [196, 300], [262, 140], [300, 220], [356, 270],
  [420, 160], [462, 330], [530, 200], [580, 240], [640, 170], [690, 290], [752, 190], [800, 230],
  [860, 150], [900, 280], [966, 200], [1020, 250], [1080, 160], [1130, 300], [1196, 210], [1250, 180],
] as const;

function windows() {
  const out: { x: number; y: number; lit: boolean; blink: boolean }[] = [];
  BUILDINGS.forEach(([x, h], i) => {
    const next = BUILDINGS[i + 1]?.[0] ?? 1300;
    const w = next - x;
    for (let wy = 420 - h + 18; wy < 400; wy += 22) {
      for (let wx = x + 8; wx < x + w - 10; wx += 14) {
        const seed = (wx * 7 + wy * 13 + i * 31) % 17;
        if (seed < 5) out.push({ x: wx, y: wy, lit: true, blink: seed === 0 });
      }
    }
  });
  return out;
}
const WINDOWS = windows();

type Mood = 'night' | 'dawn' | 'day';

export const CityBackdrop = memo(function CityBackdrop({ mood = 'night', rain = true }: { mood?: Mood; rain?: boolean }) {
  const sky =
    mood === 'day'
      ? 'linear-gradient(180deg,#2a1d14 0%,#4a2a17 45%,#120b08 100%)'
      : mood === 'dawn'
        ? 'linear-gradient(180deg,#05060b 0%,#2a0c12 55%,#4b1d14 100%)'
        : 'linear-gradient(180deg,#000 0%,#07080f 50%,#14060a 100%)';
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden grain" style={{ background: sky, transition: 'background 1.2s' }}>
      <div className="sweep" />
      <svg className="absolute bottom-0 left-0 h-[46vh] w-full" viewBox="0 0 1300 420" preserveAspectRatio="xMidYMax slice">
        <defs>
          <linearGradient id="bld" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#0d0d11" />
            <stop offset="1" stopColor="#000" />
          </linearGradient>
        </defs>
        {BUILDINGS.map(([x, h], i) => {
          const next = BUILDINGS[i + 1]?.[0] ?? 1300;
          return <rect key={x} x={x} y={420 - h} width={next - x + 1} height={h} fill="url(#bld)" />;
        })}
        {WINDOWS.map((w) => (
          <rect
            key={`${w.x}-${w.y}`}
            x={w.x}
            y={w.y}
            width={6}
            height={9}
            fill={mood === 'day' ? '#2a2016' : '#e8b44a'}
            opacity={mood === 'day' ? 0.5 : 0.75}
            className={w.blink ? 'window-light' : undefined}
          />
        ))}
      </svg>
      {rain && <div className={`rain ${mood === 'day' ? 'slow' : ''}`} />}
      <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-black to-transparent" />
    </div>
  );
});
