'use client';
import { motion } from 'framer-motion';
import { useState } from 'react';
import { teamOf, type GameView } from '@mafia/shared';
import { Button } from './Button';
import { Confetti } from './Confetti';
import { ROLE_META } from '@/lib/roleMeta';
import { useT } from '@/lib/i18n';
import type { GameActions } from '@/lib/useGame';

export function GameOver({ view, actions }: { view: GameView; actions: GameActions }) {
  const t = useT();
  const [busy, setBusy] = useState<'again' | 'lobby' | null>(null);
  const [error, setError] = useState<string | null>(null);
  if (!view.winner) return null;
  const mafiaWon = view.winner === 'MAFIA';
  const iWon = !!view.me.role && teamOf(view.me.role) === view.winner;
  const roles = view.finalRoles ?? [];

  const run = async (kind: 'again' | 'lobby') => {
    setBusy(kind);
    const res = await (kind === 'again' ? actions.replay() : actions.lobby());
    setBusy(null);
    setError(res.ok ? null : (res.error ?? null));
  };

  return (
    <div className="space-y-6 py-4 text-center">
      {iWon && <Confetti />}
      <motion.div initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: 'spring', damping: 12 }}>
        <p className="text-7xl">🏆</p>
        <h2 className={`mt-2 font-deco text-4xl tracking-wider ${mafiaWon ? 'neon-sign' : 'text-gold'}`}>{mafiaWon ? t.gameOver.mafia : t.gameOver.town}</h2>
        <p className="mt-1 font-ruqaa text-2xl">{mafiaWon ? t.gameOver.mafiaAr : t.gameOver.townAr}</p>
        <p className={`mt-2 font-bold ${iWon ? 'text-gold' : 'text-smoke'}`}>{iWon ? t.gameOver.youWon : t.gameOver.youLost}</p>
      </motion.div>

      <section className="text-start">
        <h3 className="mb-2 font-ruqaa text-2xl text-gold">{t.gameOver.roles}</h3>
        <ul className="divide-y divide-white/5 rounded-[3px] border border-white/10 bg-black/60">
          {roles.map((r, i) => {
            const p = view.players.find((x) => x.id === r.id);
            const won = teamOf(r.role) === view.winner;
            return (
              <motion.li
                key={r.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 + i * 0.08 }}
                className="flex items-center justify-between px-3 py-2.5"
              >
                <span className={`flex items-center gap-2 ${p?.alive ? '' : 'opacity-60'}`}>
                  <span>{p?.alive ? p.avatar : '☠️'}</span>
                  <span className="font-bold">{p?.name}</span>
                  {won && <span className="text-xs text-gold">🏆</span>}
                </span>
                <span style={{ color: ROLE_META[r.role].accent }}>
                  {ROLE_META[r.role].icon} {t.roles[r.role].name}
                </span>
              </motion.li>
            );
          })}
        </ul>
      </section>

      {view.me.isHost ? (
        <div className="grid gap-2">
          <Button loading={busy === 'again'} onClick={() => run('again')}>
            🔁 {t.gameOver.again}
          </Button>
          <Button variant="secondary" loading={busy === 'lobby'} onClick={() => run('lobby')}>
            {t.gameOver.lobby}
          </Button>
        </div>
      ) : (
        <p className="text-smoke">{t.gameOver.waitHost}</p>
      )}
      {error && <p className="text-sm text-neon">{error}</p>}
    </div>
  );
}
