'use client';
import { AnimatePresence, motion } from 'framer-motion';
import { useState } from 'react';
import { phaseSeconds, type ChatMessage, type GameView, type Phase } from '@mafia/shared';
import { CityBackdrop } from './CityBackdrop';
import { ChatBox, DeadChat, MafiaChat } from './ChatBox';
import { DayScreen } from './DayScreen';
import { GameOver } from './GameOver';
import { Lobby } from './Lobby';
import { NightScreen } from './NightScreen';
import { RoleCard } from './RoleCard';
import { Settings } from './Settings';
import { Timer } from './Timer';
import { VoteResults } from './VoteResults';
import { VotingScreen } from './VotingScreen';
import { useT } from '@/lib/i18n';
import type { GameActions } from '@/lib/useGame';

const DAYTIME: Phase[] = ['DAY', 'DISCUSSION', 'VOTING', 'RESULT'];

interface Props {
  view: GameView;
  messages: ChatMessage[];
  actions: GameActions;
  clockOffset: number;
  onLeave: () => void;
}

export function GameRoom({ view, messages, actions, clockOffset, onLeave }: Props) {
  const t = useT();
  const [settingsOpen, setSettingsOpen] = useState(false);
  const { phase } = view;
  const isMafia = view.me.role === 'MAFIA';
  const inGame = phase !== 'LOBBY' && phase !== 'GAME_OVER';
  const deadInGame = inGame && !view.me.alive;
  const mood = phase === 'NIGHT' || phase === 'ROLE_REVEAL' ? 'night' : DAYTIME.includes(phase) ? (phase === 'DAY' ? 'dawn' : 'day') : 'night';

  const chatCommon = { messages, myId: view.me.id, onSend: actions.chat };
  const chats = (
    <>
      {(phase === 'LOBBY' || phase === 'GAME_OVER') && (
        <ChatBox channel="LOBBY" title={`💬 ${t.chat.lobby}`} canSend {...chatCommon} className="h-72 lg:h-[420px]" />
      )}
      {DAYTIME.includes(phase) && (
        <ChatBox channel="PUBLIC" title={`💬 ${t.chat.public}`} canSend={view.me.alive} {...chatCommon} className="h-72 lg:h-[420px]" />
      )}
      {phase === 'NIGHT' && isMafia && view.me.alive && <MafiaChat canSend {...chatCommon} className="h-64" />}
      {deadInGame && <DeadChat canSend {...chatCommon} className="h-56" />}
    </>
  );

  let screen: React.ReactNode;
  switch (phase) {
    case 'LOBBY':
      screen = <Lobby view={view} actions={actions} onLeave={onLeave} />;
      break;
    case 'ROLE_REVEAL':
      screen = <RoleCard view={view} actions={actions} />;
      break;
    case 'NIGHT':
      screen = <NightScreen view={view} actions={actions} />;
      break;
    case 'DAY':
    case 'DISCUSSION':
      screen = <DayScreen view={view} actions={actions} />;
      break;
    case 'VOTING':
      screen = <VotingScreen view={view} actions={actions} />;
      break;
    case 'RESULT':
      screen = <VoteResults view={view} />;
      break;
    case 'GAME_OVER':
      screen = <GameOver view={view} actions={actions} />;
      break;
  }

  return (
    <div className="relative min-h-dvh">
      <CityBackdrop mood={mood} rain={phase !== 'DAY'} />

      <header className="sticky top-0 z-30 border-b border-white/5 bg-black/70 backdrop-blur-md">
        <div className="mx-auto flex max-w-5xl items-center gap-3 px-4 py-2">
          <div className="min-w-0 flex-1">
            <p className="font-deco text-sm tracking-widest text-neon/90">MAFIA NIGHT</p>
            <p className="truncate text-sm text-smoke">
              <span className="text-bone">{t.phase[phase]}</span>
              {view.round > 0 && inGame ? ` — ${t.round(view.round)}` : ''}
              <span className="ms-2 font-deco tracking-widest text-gold/80" dir="ltr">
                {view.roomCode}
              </span>
            </p>
          </div>
          <Timer endsAt={view.endsAt} total={phaseSeconds(phase, view.settings)} offset={clockOffset} heartbeat={phase === 'NIGHT'} />
          <button
            onClick={() => setSettingsOpen(true)}
            className="flex h-11 w-11 items-center justify-center rounded-full border border-white/10 text-xl hover:border-gold/60"
            aria-label={t.settings.title}
          >
            ⚙️
          </button>
        </div>
      </header>

      {deadInGame && (
        <div className="border-b border-moon/20 bg-moon/10 px-4 py-2 text-center text-sm text-moon">☠️ {t.status.dead}</div>
      )}

      <main className="mx-auto grid max-w-5xl gap-5 px-4 pb-[calc(2rem+var(--safe-bottom))] pt-5 lg:grid-cols-[1fr_360px]">
        <AnimatePresence mode="wait">
          <motion.div
            key={`${phase}-${view.round}`}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="min-w-0"
          >
            {screen}
          </motion.div>
        </AnimatePresence>
        <aside className="flex min-w-0 flex-col gap-3">{chats}</aside>
      </main>

      <Settings
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        room={{
          settings: view.settings,
          editable: view.me.isHost && phase === 'LOBBY',
          onChange: (patch) => void actions.settings(patch),
        }}
      />
    </div>
  );
}
