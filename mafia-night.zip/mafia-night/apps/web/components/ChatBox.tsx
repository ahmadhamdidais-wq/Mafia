'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import { LIMITS, type ChatChannel, type ChatMessage } from '@mafia/shared';
import { useT } from '@/lib/i18n';

const EMOJIS = ['😂', '🤔', '😱', '🔪', '🙄', '👀', '🤫', '👍'];

const THEME: Record<ChatChannel, { border: string; title: string }> = {
  LOBBY: { border: 'border-white/10', title: 'text-gold' },
  PUBLIC: { border: 'border-white/10', title: 'text-gold' },
  MAFIA: { border: 'border-neon/40', title: 'text-neon' },
  DEAD: { border: 'border-moon/30', title: 'text-moon' },
};

interface Props {
  channel: ChatChannel;
  title: string;
  messages: ChatMessage[];
  myId: string;
  canSend: boolean;
  onSend: (channel: ChatChannel, text: string) => Promise<{ ok: boolean; error?: string }>;
  className?: string;
}

export function ChatBox({ channel, title, messages, myId, canSend, onSend, className = '' }: Props) {
  const t = useT();
  const [text, setText] = useState('');
  const [error, setError] = useState<string | null>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const visible = useMemo(() => messages.filter((m) => m.channel === channel), [messages, channel]);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' });
  }, [visible.length]);

  const send = async (value: string) => {
    const v = value.trim();
    if (!v) return;
    const res = await onSend(channel, v);
    if (res.ok) {
      setText('');
      setError(null);
    } else setError(res.error ?? null);
  };

  const theme = THEME[channel];
  return (
    <section className={`flex min-h-0 flex-col rounded-[3px] border bg-black/70 backdrop-blur-sm ${theme.border} ${className}`}>
      <h3 className={`border-b border-white/5 px-3 py-2 text-sm font-bold ${theme.title}`}>{title}</h3>
      <div ref={listRef} className="scroll-thin min-h-[120px] flex-1 space-y-1.5 overflow-y-auto px-3 py-2" aria-live="polite">
        {visible.length === 0 && <p className="py-4 text-center text-sm text-smoke">{t.chat.empty}</p>}
        {visible.map((m) =>
          m.senderId === null ? (
            <p key={m.id} className="text-center text-xs italic text-smoke">
              {m.text}
            </p>
          ) : (
            <p key={m.id} className="break-words text-[15px] leading-snug">
              <span className={`font-bold ${m.senderId === myId ? 'text-gold' : 'text-bone/70'}`}>{m.senderName}: </span>
              <span>{m.text}</span>
            </p>
          ),
        )}
      </div>
      {canSend ? (
        <div className="border-t border-white/5 p-2">
          <div className="mb-2 flex gap-1 overflow-x-auto">
            {EMOJIS.map((e) => (
              <button key={e} type="button" onClick={() => send(e)} className="h-9 min-w-9 rounded-[3px] bg-white/5 text-lg hover:bg-white/10" aria-label={e}>
                {e}
              </button>
            ))}
          </div>
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              void send(text);
            }}
          >
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              maxLength={LIMITS.CHAT_MAX}
              placeholder={t.chat.placeholder}
              aria-label={t.chat.placeholder}
              className="h-11 min-w-0 flex-1 rounded-[3px] border border-white/10 bg-char px-3 text-bone placeholder:text-white/25 focus:border-gold focus:outline-none"
            />
            <button type="submit" className="h-11 rounded-[3px] bg-blood px-4 font-bold text-bone hover:bg-[#82121a]">
              {t.chat.send}
            </button>
          </form>
          {error && <p className="mt-1 text-xs text-neon">{error}</p>}
        </div>
      ) : (
        <p className="border-t border-white/5 px-3 py-2 text-center text-xs text-smoke">{t.chat.closed}</p>
      )}
    </section>
  );
}

type ChannelProps = Omit<Props, 'channel' | 'title'>;

export function MafiaChat(props: ChannelProps) {
  const t = useT();
  return <ChatBox channel="MAFIA" title={`🔪 ${t.chat.mafia}`} {...props} />;
}

export function DeadChat(props: ChannelProps) {
  const t = useT();
  return <ChatBox channel="DEAD" title={`☠️ ${t.chat.dead}`} {...props} />;
}
