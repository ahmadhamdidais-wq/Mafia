import type { Config } from 'tailwindcss';

export default {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#000000',
        char: '#16161a',
        steel: '#26262c',
        smoke: '#8f877a',
        bone: '#ebe3d1',
        blood: '#6e0e14',
        neon: '#ff2d3f',
        gold: '#c8a24a',
        moon: '#9fb3d1',
      },
      fontFamily: {
        body: ['var(--font-body)', 'system-ui', 'sans-serif'],
        ruqaa: ['var(--font-ruqaa)', 'var(--font-body)', 'serif'],
        deco: ['var(--font-deco)', 'Georgia', 'serif'],
      },
      boxShadow: {
        neon: '0 0 6px #ff2d3f, 0 0 24px rgba(255,45,63,.55), 0 0 60px rgba(255,45,63,.25)',
        gold: '0 0 0 1px rgba(200,162,74,.55), 0 10px 30px -10px rgba(0,0,0,.9)',
      },
    },
  },
  plugins: [],
} satisfies Config;
