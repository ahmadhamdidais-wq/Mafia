/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  transpilePackages: ['@mafia/shared'],
  poweredByHeader: false,
};
export default nextConfig;
