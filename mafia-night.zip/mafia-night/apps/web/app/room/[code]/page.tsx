'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import { ROOM_CODE_REGEX } from '@mafia/shared';
import { Button } from '@/components/Button';
import { CityBackdrop } from '@/components/CityBackdrop';
import { ConnectionBanner } from '@/components/ConnectionBanner';
import { GameRoom } from '@/components/GameRoom';
import { TextField } from '@/components/TextField';
import { api, ApiError } from '@/lib/api';
import { useT } from '@/lib/i18n';
import { loadSession, saveSession } from '@/lib/session';
import { useGame } from '@/lib/useGame';

type Stage = { kind: 'checking' } | { kind: 'name'; error?: string } | { kind: 'joined'; token: string } | { kind: 'missing' };

export default function RoomPage({ params }: { params: { code: string } }) {
  const t = useT();
  const router = useRouter();
  const code = params.code.toUpperCase();
  const [stage, setStage] = useState<Stage>({ kind: 'checking' });
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);

  const join = useCallback(
    async (playerName: string) => {
      const session = loadSession();
      try {
        const res = await api.joinRoom(code, playerName, session?.userToken);
        saveSession(res);
        setStage({ kind: 'joined', token: res.userToken });
      } catch (e) {
        if (e instanceof ApiError && (e.status === 404 || e.status === 400)) setStage({ kind: 'missing' });
        else setStage({ kind: 'name', error: (e as Error).message });
      }
    },
    [code],
  );

  // Returning players (same device) rejoin automatically — this is also how a reload reconnects.
  useEffect(() => {
    if (!ROOM_CODE_REGEX.test(code)) return setStage({ kind: 'missing' });
    const s = loadSession();
    if (s) {
      setName(s.name);
      void join(s.name);
    } else setStage({ kind: 'name' });
  }, [code, join]);

  const game = useGame(code, stage.kind === 'joined' ? stage.token : null);

  const leave = async () => {
    await game.actions.leave();
    router.push('/');
  };

  if (stage.kind === 'missing') {
    return (
      <CenterCard>
        <p className="text-5xl">🚪</p>
        <p className="text-lg">{t.errors.roomNotFound}</p>
        <Link href="/" className="text-gold underline underline-offset-4">
          {t.status.backHome}
        </Link>
      </CenterCard>
    );
  }

  if (stage.kind === 'name') {
    return (
      <CenterCard>
        <p className="neon-sign font-deco text-4xl" dir="ltr">
          MAFIA NIGHT
        </p>
        <p className="font-ruqaa text-2xl text-gold">
          {t.home.join} <span dir="ltr">{code}</span>
        </p>
        <form
          className="w-full space-y-4 text-start"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            await join(name);
            setBusy(false);
          }}
        >
          <TextField label={t.forms.yourName} placeholder={t.forms.namePlaceholder} value={name} onChange={(e) => setName(e.target.value)} minLength={2} maxLength={16} autoFocus required />
          {stage.error && <p className="text-sm text-neon">{stage.error}</p>}
          <Button type="submit" className="w-full" loading={busy}>
            {t.forms.join}
          </Button>
        </form>
      </CenterCard>
    );
  }

  if (game.status === 'kicked' || game.status === 'denied') {
    return (
      <CenterCard>
        <p className="text-5xl">🚪</p>
        <p className="text-lg">{game.status === 'kicked' ? `${t.status.kicked}${game.statusDetail ? ` — ${game.statusDetail}` : ''}` : t.errors.roomNotFound}</p>
        <Link href="/" className="text-gold underline underline-offset-4">
          {t.status.backHome}
        </Link>
      </CenterCard>
    );
  }

  if (!game.view) {
    return (
      <CenterCard>
        <span className="h-10 w-10 animate-spin rounded-full border-2 border-gold border-t-transparent" />
        <p className="text-smoke">{t.status.connecting}</p>
      </CenterCard>
    );
  }

  return (
    <>
      <ConnectionBanner status={game.status} />
      <GameRoom view={game.view} messages={game.messages} actions={game.actions} clockOffset={game.clockOffset} onLeave={leave} />
    </>
  );
}

function CenterCard({ children }: { children: React.ReactNode }) {
  return (
    <main className="relative flex min-h-dvh items-center justify-center px-6">
      <CityBackdrop />
      <div className="deco-frame flex w-full max-w-sm flex-col items-center gap-4 rounded-[3px] bg-black/75 p-6 text-center backdrop-blur-sm">{children}</div>
    </main>
  );
}
