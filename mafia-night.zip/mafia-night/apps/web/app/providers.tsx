'use client';
import { MotionConfig } from 'framer-motion';
import type { ReactNode } from 'react';
import { I18nProvider } from '@/lib/i18n';
import { PrefsProvider } from '@/lib/prefs';

export function Providers({ children }: { children: ReactNode }) {
  return (
    <I18nProvider locale="ar">
      <PrefsProvider>
        <MotionConfig reducedMotion="user">{children}</MotionConfig>
      </PrefsProvider>
    </I18nProvider>
  );
}
