import type { Metadata, Viewport } from 'next';
import { Aref_Ruqaa, IBM_Plex_Sans_Arabic, Limelight } from 'next/font/google';
import './globals.css';
import { Providers } from './providers';

const body = IBM_Plex_Sans_Arabic({ subsets: ['arabic'], weight: ['400', '500', '700'], variable: '--font-body', display: 'swap' });
const ruqaa = Aref_Ruqaa({ subsets: ['arabic'], weight: ['400', '700'], variable: '--font-ruqaa', display: 'swap' });
const deco = Limelight({ subsets: ['latin'], weight: '400', variable: '--font-deco', display: 'swap' });

export const metadata: Metadata = {
  title: 'MAFIA NIGHT — مين فيكم عم بكذب؟',
  description: 'لعبة مافيا أونلاين مع أصدقائك. أنشئ غرفة، أرسل الرابط، والعبوا مباشرة من الهاتف.',
  openGraph: {
    title: 'MAFIA NIGHT',
    description: 'مين فيكم عم بكذب؟ تعال العب مافيا معنا.',
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  viewportFit: 'cover',
  themeColor: '#000000',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={`${body.variable} ${ruqaa.variable} ${deco.variable}`}>
      <body className="min-h-dvh bg-ink font-body text-bone antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
