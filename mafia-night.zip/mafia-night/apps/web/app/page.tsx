'use client';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import type { JoinResponse } from '@mafia/shared';
import { ROOM_CODE_REGEX } from '@mafia/shared';
import { Button } from '@/components/Button';
import { CityBackdrop } from '@/components/CityBackdrop';
import { Modal } from '@/components/Modal';
import { TextField } from '@/components/TextField';
import { api } from '@/lib/api';
import { useT } from '@/lib/i18n';
import { loadSession, saveSession } from '@/lib/session';

export default function Home() {
  const t = useT();
  const router = useRouter();
  const [mode, setMode] = useState<'create' | 'join' | null>(null);
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [created, setCreated] = useState<JoinResponse | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const s = loadSession();
    if (s) setName(s.name);
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const token = loadSession()?.userToken;
      if (mode === 'create') {
        const res = await api.createRoom(name, token);
        saveSession(res);
        setMode(null);
        setCreated(res);
      } else {
        const c = code.trim().toUpperCase();
        if (!ROOM_CODE_REGEX.test(c)) throw new Error('رمز الغرفة يتكون من 5 أحرف وأرقام.');
        const res = await api.joinRoom(c, name, token);
        saveSession(res);
        router.push(`/room/${res.roomCode}`);
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const inviteUrl = created ? `${window.location.origin}/room/${created.roomCode}` : '';
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(inviteUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {}
  };
  const share = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title: 'MAFIA NIGHT', text: t.created.shareText, url: inviteUrl });
      } catch {}
    } else void copy();
  };

  return (
    <main className="relative flex min-h-dvh flex-col items-center justify-center px-6 pb-[18vh] pt-10">
      <CityBackdrop />

      <motion.div
        className="flex flex-col items-center text-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.4 }}
      >
        <h1 className="neon-sign text-[clamp(3.2rem,15vw,7.5rem)] leading-[0.9]" dir="ltr">
          MAFIA <span className="dim">NIGHT</span>
        </h1>
        <motion.p
          className="mt-5 font-ruqaa text-[clamp(1.8rem,7vw,2.8rem)] text-gold"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1, duration: 0.9 }}
        >
          {t.tagline}
        </motion.p>
      </motion.div>

      <motion.nav
        className="mt-10 flex w-full max-w-sm flex-col gap-3"
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.6, duration: 0.6 }}
      >
        <Button onClick={() => setMode('create')}>{t.home.create}</Button>
        <Button variant="secondary" onClick={() => setMode('join')}>
          {t.home.join}
        </Button>
        <div className="grid grid-cols-2 gap-3">
          <Link href="/how-to-play" className="flex min-h-[48px] items-center justify-center rounded-[3px] border border-white/10 bg-black/50 text-bone/85 hover:border-white/30">
            {t.home.howTo}
          </Link>
          <Link href="/roles" className="flex min-h-[48px] items-center justify-center rounded-[3px] border border-white/10 bg-black/50 text-bone/85 hover:border-white/30">
            {t.home.roles}
          </Link>
        </div>
        <Link href="/profile" className="py-2 text-center text-sm text-smoke hover:text-gold">
          {t.home.profile}
        </Link>
        <p className="text-center text-xs text-smoke/70">{t.home.players}</p>
      </motion.nav>

      <Modal open={mode !== null} onClose={() => setMode(null)} title={mode === 'create' ? t.home.create : t.home.join}>
        <form onSubmit={submit} className="space-y-4">
          {mode === 'join' && (
            <TextField
              label={t.forms.roomCode}
              placeholder={t.forms.codePlaceholder}
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              maxLength={5}
              autoCapitalize="characters"
              autoComplete="off"
              dir="ltr"
              className="h-14 w-full rounded-[3px] border border-white/15 bg-black/70 px-4 text-center font-deco text-2xl tracking-[0.3em] text-gold focus:border-gold focus:outline-none"
              required
            />
          )}
          <TextField
            label={t.forms.yourName}
            placeholder={t.forms.namePlaceholder}
            value={name}
            onChange={(e) => setName(e.target.value)}
            minLength={2}
            maxLength={16}
            autoFocus
            required
          />
          {error && <p className="text-sm text-neon">{error}</p>}
          <Button type="submit" className="w-full" loading={busy}>
            {mode === 'create' ? t.forms.create : t.forms.join}
          </Button>
        </form>
      </Modal>

      <Modal open={!!created} onClose={() => setCreated(null)} title={t.created.title}>
        {created && (
          <div className="space-y-4 text-center">
            <div>
              <p className="text-sm text-smoke">{t.created.code}</p>
              <p className="font-deco text-5xl tracking-[0.25em] text-gold" dir="ltr">
                {created.roomCode}
              </p>
            </div>
            <div>
              <p className="mb-1 text-sm text-smoke">{t.created.link}</p>
              <p className="break-all rounded-[3px] bg-black/60 px-3 py-2 text-sm" dir="ltr">
                {inviteUrl}
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Button variant="secondary" size="md" onClick={copy}>
                {copied ? `✓ ${t.created.copied}` : t.created.copy}
              </Button>
              <Button variant="secondary" size="md" onClick={share}>
                {t.created.share}
              </Button>
            </div>
            <Button className="w-full" onClick={() => router.push(`/room/${created.roomCode}`)}>
              {t.created.enter}
            </Button>
          </div>
        )}
      </Modal>
    </main>
  );
}
