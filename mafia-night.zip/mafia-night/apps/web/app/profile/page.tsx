'use client';
import { useEffect, useState } from 'react';
import type { PlayerProfile } from '@mafia/shared';
import { AchievementPanel } from '@/components/AchievementPanel';
import { InfoPage } from '@/components/InfoPage';
import { api } from '@/lib/api';
import { useT } from '@/lib/i18n';
import { loadSession } from '@/lib/session';

export default function Profile() {
  const t = useT();
  const [profile, setProfile] = useState<PlayerProfile | null>(null);
  const [state, setState] = useState<'loading' | 'none' | 'ok'>('loading');

  useEffect(() => {
    const s = loadSession();
    if (!s) return setState('none');
    api
      .player(s.userId)
      .then((p) => {
        setProfile(p);
        setState('ok');
      })
      .catch(() => setState('none'));
  }, []);

  if (state !== 'ok' || !profile) {
    return (
      <InfoPage title={t.profile.title}>
        <p className="text-smoke">{state === 'loading' ? '...' : t.profile.none}</p>
      </InfoPage>
    );
  }

  const s = profile.stats;
  const stats: [string, number][] = [
    [t.profile.games, s.gamesPlayed],
    [t.profile.wins, s.wins],
    [t.profile.losses, s.losses],
    [t.profile.mafiaWins, s.mafiaWins],
    [t.profile.citizenWins, s.citizenWins],
    [t.profile.detectiveWins, s.detectiveWins],
    [t.profile.doctorSaves, s.doctorSaves],
    [t.profile.eliminated, s.playersEliminated],
  ];
  const nextLevelXp = profile.level ** 2 * 100;
  const prevLevelXp = (profile.level - 1) ** 2 * 100;
  const pct = Math.min(1, (profile.xp - prevLevelXp) / (nextLevelXp - prevLevelXp));

  return (
    <InfoPage title={profile.name}>
      <section className="deco-frame rounded-[3px] bg-black/60 p-4">
        <div className="flex items-baseline justify-between">
          <span className="text-smoke">{t.profile.level}</span>
          <span className="font-deco text-4xl text-gold">{profile.level}</span>
        </div>
        <div className="mt-2 h-2 overflow-hidden rounded-sm bg-white/10">
          <div className="h-full bg-gold" style={{ width: `${pct * 100}%` }} />
        </div>
        <p className="mt-1 text-xs tabular-nums text-smoke">
          {profile.xp} / {nextLevelXp} {t.profile.xp}
        </p>
      </section>
      <dl className="grid grid-cols-2 gap-2">
        {stats.map(([label, value]) => (
          <div key={label} className="rounded-[3px] border border-white/10 bg-black/50 p-3">
            <dt className="text-xs text-smoke">{label}</dt>
            <dd className="text-2xl font-bold tabular-nums">{value}</dd>
          </div>
        ))}
      </dl>
      <AchievementPanel unlocked={profile.achievements} />
    </InfoPage>
  );
}
