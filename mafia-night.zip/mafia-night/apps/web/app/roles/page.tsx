'use client';
import type { Role } from '@mafia/shared';
import { InfoPage } from '@/components/InfoPage';
import { ROLE_META } from '@/lib/roleMeta';
import { useT } from '@/lib/i18n';

const ORDER: Role[] = ['MAFIA', 'DETECTIVE', 'DOCTOR', 'CITIZEN'];

export default function Roles() {
  const t = useT();
  return (
    <InfoPage title="الشخصيات">
      {ORDER.map((role) => {
        const meta = ROLE_META[role];
        const text = t.roles[role];
        return (
          <article key={role} className="flex gap-4 border-b border-white/10 py-4 last:border-0">
            <span className="text-5xl" style={{ filter: `drop-shadow(0 0 16px ${meta.glow})` }}>
              {meta.icon}
            </span>
            <span>
              <h2 className="font-ruqaa text-3xl" style={{ color: meta.accent }}>
                {text.name}
              </h2>
              <p className="font-bold">{text.goal}</p>
              <p className="text-bone/75">{text.ability}</p>
            </span>
          </article>
        );
      })}
      <p className="text-sm text-smoke">قريبًا: الحارس الشخصي، المهرّج، والصيّاد.</p>
    </InfoPage>
  );
}
