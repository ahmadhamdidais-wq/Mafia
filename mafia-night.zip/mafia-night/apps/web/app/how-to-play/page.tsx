import { InfoPage } from '@/components/InfoPage';

const STEPS = [
  ['أنشئ غرفة', 'اكتب اسمك واضغط «إنشاء غرفة». ستحصل على رمز ورابط دعوة. أرسل الرابط لأصدقائك — من 5 إلى 15 لاعبًا.'],
  ['استعدوا', 'كل لاعب يضغط «أنا جاهز». عندما يكتمل العدد، يبدأ المضيف اللعبة.'],
  ['اكشف دورك', 'كل لاعب يرى بطاقته السرية فقط. لا تُظهر شاشتك لأحد.'],
  ['الليل', 'المدينة تنام. المافيا تختار ضحية وتتحدث سرًا، الطبيب يحمي لاعبًا، والمحقق يحقق مع لاعب.'],
  ['الصباح', 'يُعلن من مات الليلة — أو أن شيئًا غريبًا حدث ونجا الجميع.'],
  ['النقاش', 'تحدثوا واتهموا ودافعوا عن أنفسكم. عندما يجهز الجميع يبدأ التصويت مبكرًا.'],
  ['التصويت', 'كل لاعب حي يصوّت سرًا. صاحب أكثر الأصوات يخرج. التعادل لا يُخرج أحدًا.'],
  ['النهاية', 'المواطنون يفوزون عند إخراج كل المافيا. المافيا تفوز عندما يصبح عددها مساويًا لعدد البقية.'],
];

export default function HowToPlay() {
  return (
    <InfoPage title="طريقة اللعب">
      <ol className="space-y-5">
        {STEPS.map(([title, body], i) => (
          <li key={title} className="flex gap-4">
            <span className="mt-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-gold/50 font-deco text-gold">{i + 1}</span>
            <span>
              <strong className="block text-lg">{title}</strong>
              <span className="text-bone/80">{body}</span>
            </span>
          </li>
        ))}
      </ol>
      <p className="border-t border-white/10 pt-4 text-sm text-smoke">
        الموتى يستطيعون مشاهدة اللعبة والتحدث فيما بينهم فقط. إذا انقطع اتصالك، لديك 60 ثانية للعودة قبل أن تخرج من المباراة.
      </p>
    </InfoPage>
  );
}
