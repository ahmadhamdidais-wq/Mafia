import type { Server as HttpServer } from 'node:http';
import { Server, type Socket } from 'socket.io';
import type { Ack, ClientToServerEvents, ServerToClientEvents } from '@mafia/shared';
import { GameError } from '../domain/GameEngine';
import { normalizeRoomCode } from '../domain/validation';
import type { Broadcaster, RoomManager } from '../services/RoomManager';
import type { UserService } from '../services/UserService';
import { RateLimiter } from '../infra/rateLimit';
import { config } from '../config';

interface SocketData {
  userId: string;
  roomCode: string;
}
type IO = Server<ClientToServerEvents, ServerToClientEvents, Record<string, never>, SocketData>;
type S = Socket<ClientToServerEvents, ServerToClientEvents, Record<string, never>, SocketData>;

const personal = (code: string, userId: string) => `${code}:${userId}`;

export function createSocketServer(http: HttpServer): IO {
  return new Server(http, {
    cors: config.corsOrigin.length ? { origin: config.corsOrigin } : undefined,
    // Let Next.js dev server handle its own HMR websocket upgrades.
    destroyUpgrade: false,
    maxHttpBufferSize: 8_000,
    pingInterval: 10_000,
    pingTimeout: 8_000,
  });
}

export class SocketBroadcaster implements Broadcaster {
  constructor(private readonly io: IO) {}
  state(code: string, userId: string, view: Parameters<Broadcaster['state']>[2]) {
    this.io.to(personal(code, userId)).emit('room:state', view);
  }
  phase(code: string, notice: Parameters<Broadcaster['phase']>[1]) {
    this.io.to(code).emit('game:phase', notice);
  }
  chat(code: string, userId: string, msg: Parameters<Broadcaster['chat']>[2]) {
    this.io.to(personal(code, userId)).emit('chat:message', msg);
  }
  chatHistory(code: string, userId: string, msgs: Parameters<Broadcaster['chatHistory']>[2]) {
    this.io.to(personal(code, userId)).emit('chat:history', msgs);
  }
  gameEnd(code: string, winner: Parameters<Broadcaster['gameEnd']>[1]) {
    this.io.to(code).emit('game:end', { winner });
  }
  kicked(code: string, userId: string, reason: string) {
    const room = personal(code, userId);
    this.io.to(room).emit('room:kicked', { reason });
    this.io.in(room).disconnectSockets(true);
  }
}

export function attachHandlers(io: IO, rooms: RoomManager, users: UserService) {
  const eventLimit = new RateLimiter(20, 4); // general actions
  const chatLimit = new RateLimiter(6, 1); // chat: 6 burst, 1/sec

  // Authenticate every connection before it can do anything.
  io.use(async (socket, next) => {
    try {
      const auth = socket.handshake.auth as Record<string, unknown>;
      const code = normalizeRoomCode(auth?.roomCode);
      const user = await users.resolve(auth?.userToken);
      if (!code || !user) return next(new Error('UNAUTHORIZED'));
      if (!rooms.getRoom(code)) return next(new Error('ROOM_NOT_FOUND'));
      if (!rooms.isMember(code, user.id)) return next(new Error('NOT_A_MEMBER'));
      socket.data = { userId: user.id, roomCode: code };
      next();
    } catch (e) {
      next(e as Error);
    }
  });

  io.on('connection', (socket: S) => {
    const { userId, roomCode } = socket.data;
    socket.join(roomCode);
    socket.join(personal(roomCode, userId));
    rooms.connect(roomCode, userId);

    /** Wraps a handler: rate limit, server-side validation, uniform ack. */
    const handle =
      (fn: (...args: unknown[]) => void, limiter = eventLimit) =>
      (...args: unknown[]) => {
        const ack = (typeof args[args.length - 1] === 'function' ? args.pop() : undefined) as Ack | undefined;
        if (!limiter.take(socket.id)) return ack?.({ ok: false, error: 'تمهّل قليلًا.' });
        try {
          fn(...args);
          ack?.({ ok: true });
        } catch (e) {
          if (e instanceof GameError) return ack?.({ ok: false, error: e.message });
          console.error('socket handler error', e);
          ack?.({ ok: false, error: 'حدث خطأ غير متوقع.' });
        }
      };

    const obj = (v: unknown) => (v && typeof v === 'object' ? (v as Record<string, unknown>) : {});
    const resync = () => rooms.resync(roomCode, userId);

    socket.on('room:join', handle(() => resync()));
    socket.on('player:reconnect', handle(() => resync()));
    socket.on('room:leave', handle(() => rooms.leave(roomCode, userId)));
    socket.on('player:ready', handle((p) => rooms.setReady(roomCode, userId, obj(p).ready === true)));
    socket.on('room:settings', handle((p) => rooms.updateSettings(roomCode, userId, obj(p))));
    socket.on('game:start', handle(() => rooms.startGame(roomCode, userId)));
    socket.on('role:ack', handle(() => rooms.ackRole(roomCode, userId)));
    socket.on('night:action', handle((p) => rooms.nightAction(roomCode, userId, obj(p).targetId)));
    socket.on('discussion:skip', handle(() => rooms.discussionSkip(roomCode, userId)));
    socket.on('vote:cast', handle((p) => rooms.castVote(roomCode, userId, obj(p).targetId)));
    socket.on('chat:message', handle((p) => rooms.chat(roomCode, userId, obj(p).channel, obj(p).text), chatLimit));
    socket.on('game:replay', handle(() => rooms.replay(roomCode, userId)));
    socket.on('room:lobby', handle(() => rooms.backToLobby(roomCode, userId)));

    socket.on('disconnect', () => {
      eventLimit.forget(socket.id);
      chatLimit.forget(socket.id);
      rooms.disconnect(roomCode, userId);
    });
  });
}
