import express, { type Request, type Response, type NextFunction } from 'express';
import type { JoinResponse, RoomInfo } from '@mafia/shared';
import { LIMITS } from '@mafia/shared';
import { GameError } from '../domain/GameEngine';
import { normalizeRoomCode, sanitizeName } from '../domain/validation';
import type { RoomManager } from '../services/RoomManager';
import type { UserService } from '../services/UserService';
import type { Repository } from '../infra/repositories/Repository';
import { RateLimiter } from '../infra/rateLimit';
import { config } from '../config';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function apiRouter(deps: { rooms: RoomManager; users: UserService; repo: Repository }) {
  const { rooms, users, repo } = deps;
  const router = express.Router();
  const writeLimit = new RateLimiter(15, 0.5); // 15 burst, 30/min
  const readLimit = new RateLimiter(60, 2);

  router.use(express.json({ limit: '4kb' }));

  const limit = (limiter: RateLimiter) => (req: Request, res: Response, next: NextFunction) => {
    if (!limiter.take(req.ip ?? 'unknown')) return res.status(429).json({ error: 'طلبات كثيرة، حاول بعد قليل.' });
    next();
  };

  const inviteUrl = (req: Request, code: string) => {
    const base = config.publicUrl ?? `${req.protocol}://${req.get('host')}`;
    return `${base}/room/${code}`;
  };

  router.get('/health', (_req, res) => res.json({ ok: true, db: repo.kind, rooms: rooms.rooms.size }));

  router.post('/rooms', limit(writeLimit), async (req, res, next) => {
    try {
      const name = sanitizeName(req.body?.name);
      if (!name) return res.status(400).json({ error: `الاسم يجب أن يكون بين ${LIMITS.NAME_MIN} و ${LIMITS.NAME_MAX} حرفًا.` });
      const user = await users.ensure(req.body?.userToken, name);
      const room = rooms.createRoom(user.id, name);
      const body: JoinResponse = { roomCode: room.code, inviteUrl: inviteUrl(req, room.code), userId: user.id, userToken: user.token, name };
      res.status(201).json(body);
    } catch (e) {
      next(e);
    }
  });

  router.post('/rooms/join', limit(writeLimit), async (req, res, next) => {
    try {
      const code = normalizeRoomCode(req.body?.code);
      if (!code) return res.status(400).json({ error: 'رمز الغرفة غير صحيح.' });
      const name = sanitizeName(req.body?.name);
      if (!name) return res.status(400).json({ error: `الاسم يجب أن يكون بين ${LIMITS.NAME_MIN} و ${LIMITS.NAME_MAX} حرفًا.` });
      const room = rooms.getRoom(code);
      if (!room) return res.status(404).json({ error: 'الغرفة غير موجودة.' });
      const user = await users.ensure(req.body?.userToken, name);
      rooms.joinRoom(code, user.id, room.members.get(user.id)?.name ?? name);
      const body: JoinResponse = {
        roomCode: code,
        inviteUrl: inviteUrl(req, code),
        userId: user.id,
        userToken: user.token,
        name: room.members.get(user.id)?.name ?? name,
      };
      res.json(body);
    } catch (e) {
      next(e);
    }
  });

  router.get('/rooms/:id', limit(readLimit), (req, res) => {
    const code = normalizeRoomCode(req.params.id);
    const room = code ? rooms.getRoom(code) : undefined;
    if (!room) return res.status(404).json({ error: 'الغرفة غير موجودة.' });
    const info: RoomInfo = {
      code: room.code,
      playerCount: room.members.size,
      maxPlayers: LIMITS.MAX_PLAYERS,
      phase: room.phase,
      joinable: !room.inGame && room.members.size < LIMITS.MAX_PLAYERS,
    };
    res.json(info);
  });

  router.get('/player/:id', limit(readLimit), async (req, res, next) => {
    try {
      if (!UUID.test(req.params.id)) return res.status(400).json({ error: 'معرّف غير صالح.' });
      const profile = await repo.getProfile(req.params.id);
      if (!profile) return res.status(404).json({ error: 'اللاعب غير موجود.' });
      res.json(profile);
    } catch (e) {
      next(e);
    }
  });

  router.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof GameError) return res.status(409).json({ error: err.message });
    console.error(err);
    res.status(500).json({ error: 'حدث خطأ في الخادم.' });
  });

  return router;
}
