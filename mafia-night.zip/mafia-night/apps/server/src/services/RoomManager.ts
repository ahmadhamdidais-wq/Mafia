import {
  LIMITS,
  type ChatChannel,
  type ChatMessage,
  type GameView,
  type PhaseNotice,
  type RoomSettings,
  type Winner,
} from '@mafia/shared';
import { GameError, type DomainEvent } from '../domain/GameEngine';
import { Room } from '../domain/Room';
import { projectFor } from '../domain/projection';
import { canRead, canSend } from '../domain/chatPolicy';
import { sanitizeChat } from '../domain/validation';
import { newId, roomCode, secureRng, type Rng } from '../infra/random';
import type { Repository } from '../infra/repositories/Repository';
import { StatsService } from './StatsService';

/** Output port: how the manager talks to connected clients. Implemented by the Socket.IO layer. */
export interface Broadcaster {
  state(code: string, userId: string, view: GameView): void;
  phase(code: string, notice: PhaseNotice): void;
  chat(code: string, userId: string, msg: ChatMessage): void;
  chatHistory(code: string, userId: string, msgs: ChatMessage[]): void;
  gameEnd(code: string, winner: Winner): void;
  kicked(code: string, userId: string, reason: string): void;
}

const EMPTY_ROOM_TTL_MS = 10 * 60_000;

export class RoomManager {
  readonly rooms = new Map<string, Room>();
  /** Open socket count per `${code}:${userId}` (a player may have several tabs). */
  private connections = new Map<string, number>();
  private timer: NodeJS.Timeout | null = null;

  constructor(
    private readonly repo: Repository,
    private readonly bus: Broadcaster,
    readonly stats: StatsService,
    private readonly clock: () => number = () => Date.now(),
    private readonly rng: Rng = secureRng,
    private readonly log: (...a: unknown[]) => void = console.error,
  ) {}

  // ------------------------------------------------------------- lifecycle

  /** Deadline-driven loop. Game logic lives in the engine; this only asks "is it time?". */
  startLoop(intervalMs = 250) {
    this.timer = setInterval(() => this.tick(), intervalMs);
    this.timer.unref?.();
  }

  stopLoop() {
    if (this.timer) clearInterval(this.timer);
  }

  tick() {
    const now = this.clock();
    for (const room of [...this.rooms.values()]) {
      try {
        let changed = room.engine?.tick(now) ?? false;
        changed = this.expireDisconnected(room, now) || changed;
        if (changed) this.afterChange(room);
        if (room.members.size === 0 && now - room.lastActivity > EMPTY_ROOM_TTL_MS) this.rooms.delete(room.code);
      } catch (e) {
        this.log('tick error', room.code, e);
      }
    }
  }

  private expireDisconnected(room: Room, now: number): boolean {
    let changed = false;
    for (const m of [...room.members.values()]) {
      if (m.connected || m.disconnectedAt === null) continue;
      const gone = now - m.disconnectedAt;
      if (m.id === room.hostId && gone > LIMITS.HOST_MIGRATION_MS && room.migrateHost()) {
        this.system(room, `👑 أصبح ${room.members.get(room.hostId)?.name} المضيف الجديد.`);
        changed = true;
      }
      if (gone > LIMITS.RECONNECT_GRACE_MS) {
        this.dropMember(room, m.id, 'انقطع الاتصال لفترة طويلة.');
        changed = true;
      }
    }
    return changed;
  }

  private dropMember(room: Room, userId: string, reason: string) {
    const m = room.members.get(userId);
    if (!m) return;
    const wasHost = room.hostId === userId;
    room.engine?.removePlayer(userId);
    room.removeMember(userId);
    this.bus.kicked(room.code, userId, reason);
    this.system(room, `🚪 غادر ${m.name} الغرفة.`);
    if (wasHost && room.members.size > 0) this.system(room, `👑 أصبح ${room.members.get(room.hostId)?.name} المضيف الجديد.`);
    void this.repo.removeRoomPlayer(room.code, userId).catch(this.log);
  }

  // ------------------------------------------------------------- rooms

  createRoom(hostId: string, name: string): Room {
    let code = roomCode();
    while (this.rooms.has(code)) code = roomCode();
    const room = new Room(code, hostId, this.clock());
    room.addMember(hostId, name, this.clock());
    this.rooms.set(code, room);
    void this.repo.createRoom(code, hostId).then(() => this.repo.addRoomPlayer(code, hostId)).catch(this.log);
    return room;
  }

  getRoom(code: string): Room | undefined {
    return this.rooms.get(code);
  }

  joinRoom(code: string, userId: string, name: string): Room {
    const room = this.rooms.get(code);
    if (!room) throw new GameError('الغرفة غير موجودة.');
    const isNew = !room.members.has(userId);
    room.addMember(userId, name, this.clock());
    room.lastActivity = this.clock();
    if (isNew) {
      void this.repo.addRoomPlayer(code, userId).catch(this.log);
      this.afterChange(room);
    }
    return room;
  }

  isMember(code: string, userId: string) {
    return !!this.rooms.get(code)?.members.has(userId);
  }

  // ------------------------------------------------------------- connections

  connect(code: string, userId: string) {
    const room = this.requireMember(code, userId);
    const key = `${code}:${userId}`;
    this.connections.set(key, (this.connections.get(key) ?? 0) + 1);
    const m = room.members.get(userId)!;
    const wasAway = !m.connected;
    m.connected = true;
    m.disconnectedAt = null;
    room.lastActivity = this.clock();
    if (wasAway && room.inGame) this.system(room, `🔌 عاد ${m.name} إلى اللعبة.`);
    this.bus.chatHistory(code, userId, room.chat.filter((c) => canRead(room, userId, c.channel)));
    this.afterChange(room);
  }

  /** Re-sends chat history and current view to one player (after a client-side reload/reconnect). */
  resync(code: string, userId: string) {
    const room = this.requireMember(code, userId);
    this.bus.chatHistory(code, userId, room.chat.filter((c) => canRead(room, userId, c.channel)));
    this.bus.state(code, userId, projectFor(room, userId, this.clock()));
  }

  disconnect(code: string, userId: string) {
    const room = this.rooms.get(code);
    const key = `${code}:${userId}`;
    const left = Math.max(0, (this.connections.get(key) ?? 1) - 1);
    if (left > 0) {
      this.connections.set(key, left);
      return;
    }
    this.connections.delete(key);
    const m = room?.members.get(userId);
    if (!room || !m) return;
    m.connected = false;
    m.disconnectedAt = this.clock();
    if (room.inGame) this.system(room, `📡 فقد ${m.name} الاتصال...`);
    this.afterChange(room);
  }

  leave(code: string, userId: string) {
    const room = this.requireMember(code, userId);
    this.dropMember(room, userId, 'غادرت الغرفة.');
    this.afterChange(room);
  }

  // ------------------------------------------------------------- actions

  setReady(code: string, userId: string, ready: boolean) {
    const room = this.requireMember(code, userId);
    room.setReady(userId, ready === true);
    this.afterChange(room);
  }

  updateSettings(code: string, userId: string, patch: Partial<RoomSettings>) {
    const room = this.requireMember(code, userId);
    room.updateSettings(userId, patch ?? {});
    this.afterChange(room);
  }

  startGame(code: string, userId: string, opts: { skipReadyCheck?: boolean } = {}) {
    const room = this.requireMember(code, userId);
    const engine = room.startGame(userId, this.clock, this.rng, opts);
    room.gameId = newId();
    const players = [...engine.players.values()].map((p) => ({ userId: p.id, role: p.role }));
    void this.repo.createGame({ id: room.gameId, roomCode: code, settings: room.settings, players }).catch(this.log);
    this.afterChange(room);
  }

  replay(code: string, userId: string) {
    const room = this.requireMember(code, userId);
    if (room.phase !== 'GAME_OVER') throw new GameError('هذا الإجراء غير متاح الآن.');
    room.requireHost(userId);
    room.engine = null;
    this.startGame(code, userId, { skipReadyCheck: true });
  }

  backToLobby(code: string, userId: string) {
    const room = this.requireMember(code, userId);
    room.backToLobby(userId);
    this.afterChange(room);
  }

  ackRole(code: string, userId: string) {
    const room = this.requireGame(code, userId);
    room.engine!.ackRole(userId);
    this.afterChange(room);
  }

  nightAction(code: string, userId: string, targetId: unknown) {
    const room = this.requireGame(code, userId);
    if (typeof targetId !== 'string') throw new GameError('اختيار غير صالح.');
    room.engine!.nightAction(userId, targetId);
    this.afterChange(room);
  }

  discussionSkip(code: string, userId: string) {
    const room = this.requireGame(code, userId);
    room.engine!.discussionSkip(userId);
    this.afterChange(room);
  }

  castVote(code: string, userId: string, targetId: unknown) {
    const room = this.requireGame(code, userId);
    if (typeof targetId !== 'string') throw new GameError('اختيار غير صالح.');
    room.engine!.castVote(userId, targetId);
    this.afterChange(room);
  }

  chat(code: string, userId: string, channel: unknown, rawText: unknown) {
    const room = this.requireMember(code, userId);
    const ch = channel as ChatChannel;
    if (!['LOBBY', 'PUBLIC', 'MAFIA', 'DEAD'].includes(ch)) throw new GameError('قناة غير صالحة.');
    if (!canSend(room, userId, ch)) throw new GameError('لا يمكنك الكتابة في هذه القناة الآن.');
    const text = sanitizeChat(rawText);
    if (!text) throw new GameError('رسالة فارغة.');
    const m = room.members.get(userId)!;
    this.deliver(room, { id: newId(), channel: ch, senderId: userId, senderName: m.name, text, at: this.clock() });
  }

  // ------------------------------------------------------------- internals

  private requireMember(code: string, userId: string): Room {
    const room = this.rooms.get(code);
    if (!room) throw new GameError('الغرفة غير موجودة.');
    if (!room.members.has(userId)) throw new GameError('لست عضوًا في هذه الغرفة.');
    return room;
  }

  private requireGame(code: string, userId: string): Room {
    const room = this.requireMember(code, userId);
    if (!room.engine) throw new GameError('لا توجد مباراة قيد التشغيل.');
    return room;
  }

  private system(room: Room, text: string, channel: ChatChannel = room.inGame ? 'PUBLIC' : 'LOBBY') {
    this.deliver(room, { id: newId(), channel, senderId: null, senderName: 'الراوي', text, at: this.clock() });
  }

  private deliver(room: Room, msg: ChatMessage) {
    room.pushChat(msg);
    for (const id of room.members.keys()) if (canRead(room, id, msg.channel)) this.bus.chat(room.code, id, msg);
  }

  /** Drains engine events (persistence, notices) and pushes a fresh private view to each member. */
  private afterChange(room: Room) {
    const engine = room.engine;
    if (engine) {
      const events = engine.drainEvents();
      for (const ev of events) this.handleEvent(room, ev);
    }
    const now = this.clock();
    for (const id of room.members.keys()) this.bus.state(room.code, id, projectFor(room, id, now));
  }

  private handleEvent(room: Room, ev: DomainEvent) {
    const gameId = room.gameId;
    if (gameId) {
      this.stats.observe(gameId, ev);
      if (ev.type === 'VOTE') void this.repo.recordVote(gameId, ev.round, ev.voterId, ev.targetId).catch(this.log);
      else void this.repo.logEvent(gameId, 'round' in ev ? ev.round : 0, ev.type, ev).catch(this.log);
    }
    if (ev.type === 'PHASE') this.bus.phase(room.code, { phase: ev.phase, round: ev.round });
    if (ev.type === 'DEATH' && ev.cause === 'LEFT') {
      const name = room.members.get(ev.playerId)?.name ?? room.departed.get(ev.playerId)?.name;
      if (name) this.system(room, `☠️ خرج ${name} من المباراة.`);
    }
    if (ev.type === 'GAME_OVER') {
      this.bus.gameEnd(room.code, ev.winner);
      if (gameId && room.engine) {
        const engine = room.engine;
        const players = [...engine.players.values()].map((p) => ({
          userId: p.id,
          role: p.role,
          alive: p.alive,
          left: p.deathCause === 'LEFT',
          votesReceived: engine.votesReceived.get(p.id) ?? 0,
        }));
        void this.repo
          .finishGame(
            gameId,
            ev.winner,
            players.map((p) => ({ userId: p.userId, alive: p.alive, won: !p.left && (p.role === 'MAFIA') === (ev.winner === 'MAFIA') })),
          )
          .catch(this.log);
        void this.stats.finish(gameId, players, ev.winner);
      }
    }
  }
}
