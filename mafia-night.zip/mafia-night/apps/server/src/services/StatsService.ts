import { teamOf, type Role, type Winner } from '@mafia/shared';
import type { DomainEvent } from '../domain/GameEngine';
import { EMPTY_DELTA, type CumulativeStats, type Repository, type StatsDelta } from '../infra/repositories/Repository';

export const XP = { PLAY: 25, WIN: 100, SAVE: 30, FIND: 20, ELIMINATION: 10 } as const;

interface GameTally {
  saves: Map<string, number>;
  finds: Map<string, number>;
  eliminations: Map<string, number>;
}

export interface FinalPlayer {
  userId: string;
  role: Role;
  alive: boolean;
  left: boolean;
  votesReceived: number;
}

/** Accumulates per-game facts from domain events, then writes stats & achievements at game end. */
export class StatsService {
  private tallies = new Map<string, GameTally>();

  constructor(private readonly repo: Repository, private readonly log: (e: unknown) => void = console.error) {}

  observe(gameId: string, ev: DomainEvent) {
    const t = this.tally(gameId);
    const inc = (m: Map<string, number>, id: string) => m.set(id, (m.get(id) ?? 0) + 1);
    if (ev.type === 'SAVE') inc(t.saves, ev.doctorId);
    if (ev.type === 'INVESTIGATION' && ev.isMafia) inc(t.finds, ev.detectiveId);
    if (ev.type === 'DEATH') for (const id of ev.creditIds) inc(t.eliminations, id);
  }

  computeDelta(gameId: string, p: FinalPlayer, winner: Winner): StatsDelta {
    const t = this.tally(gameId);
    const won = !p.left && teamOf(p.role) === winner;
    const saves = t.saves.get(p.userId) ?? 0;
    const finds = t.finds.get(p.userId) ?? 0;
    const elims = t.eliminations.get(p.userId) ?? 0;
    return {
      ...EMPTY_DELTA,
      gamesPlayed: 1,
      wins: won ? 1 : 0,
      losses: won ? 0 : 1,
      mafiaWins: won && p.role === 'MAFIA' ? 1 : 0,
      citizenWins: won && p.role !== 'MAFIA' ? 1 : 0,
      detectiveWins: won && p.role === 'DETECTIVE' ? 1 : 0,
      doctorSaves: saves,
      detectiveFinds: finds,
      playersEliminated: elims,
      xp: XP.PLAY + (won ? XP.WIN : 0) + saves * XP.SAVE + finds * XP.FIND + elims * XP.ELIMINATION,
    };
  }

  static achievementsFor(total: CumulativeStats, p: FinalPlayer, winner: Winner, aliveTown: number): string[] {
    const keys: string[] = [];
    const won = !p.left && teamOf(p.role) === winner;
    if (total.detectiveFinds >= 5) keys.push('DETECTIVE_5');
    if (total.mafiaWins >= 10) keys.push('MAFIA_PRO');
    if (total.doctorSaves >= 1) keys.push('DOCTOR_SAVE');
    if (won && p.role === 'MAFIA' && p.votesReceived === 0) keys.push('DECEIVER');
    if (p.role !== 'MAFIA' && p.alive && aliveTown === 1) keys.push('SURVIVOR');
    return keys;
  }

  async finish(gameId: string, players: FinalPlayer[], winner: Winner) {
    const aliveTown = players.filter((p) => p.alive && p.role !== 'MAFIA').length;
    try {
      for (const p of players) {
        const total = await this.repo.applyStats(p.userId, this.computeDelta(gameId, p, winner));
        const keys = StatsService.achievementsFor(total, p, winner, aliveTown);
        if (keys.length) await this.repo.unlockAchievements(p.userId, keys);
      }
    } catch (e) {
      this.log(e);
    } finally {
      this.tallies.delete(gameId);
    }
  }

  private tally(gameId: string): GameTally {
    let t = this.tallies.get(gameId);
    if (!t) {
      t = { saves: new Map(), finds: new Map(), eliminations: new Map() };
      this.tallies.set(gameId, t);
    }
    return t;
  }
}
