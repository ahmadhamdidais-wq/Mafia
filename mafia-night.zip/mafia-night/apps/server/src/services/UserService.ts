import { createHash } from 'node:crypto';
import type { Repository } from '../infra/repositories/Repository';
import { newId, secureToken } from '../infra/random';

const hash = (token: string) => createHash('sha256').update(token).digest('hex');

/** Guest identity: a server-issued id + secret token kept in the browser. Only the hash is stored. */
export class UserService {
  private cache = new Map<string, { id: string; name: string }>();

  constructor(private readonly repo: Repository) {}

  async resolve(token: unknown): Promise<{ id: string; name: string } | null> {
    if (typeof token !== 'string' || token.length < 20 || token.length > 100) return null;
    const h = hash(token);
    const cached = this.cache.get(h);
    if (cached) return cached;
    const user = await this.repo.findUserByTokenHash(h);
    if (user) this.cache.set(h, user);
    return user;
  }

  /** Returns existing guest for this token or creates a new one. */
  async ensure(token: unknown, name: string): Promise<{ id: string; name: string; token: string }> {
    const existing = await this.resolve(token);
    if (existing && typeof token === 'string') {
      if (existing.name !== name) {
        existing.name = name;
        await this.repo.updateUserName(existing.id, name);
      }
      return { ...existing, token };
    }
    const user = { id: newId(), name };
    const fresh = secureToken();
    await this.repo.createUser({ ...user, tokenHash: hash(fresh) });
    this.cache.set(hash(fresh), user);
    return { ...user, token: fresh };
  }
}
