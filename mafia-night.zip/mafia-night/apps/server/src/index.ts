import './env';
import http from 'node:http';
import path from 'node:path';
import express from 'express';
import { config } from './config';
import { MemoryRepository } from './infra/repositories/MemoryRepository';
import type { Repository } from './infra/repositories/Repository';
import { RoomManager } from './services/RoomManager';
import { StatsService } from './services/StatsService';
import { UserService } from './services/UserService';
import { apiRouter } from './transport/http';
import { attachHandlers, createSocketServer, SocketBroadcaster } from './transport/socket';

async function createRepository(): Promise<Repository> {
  if (!config.databaseUrl) {
    console.warn('⚠️  DATABASE_URL not set — running in memory (stats reset on restart).');
    return new MemoryRepository();
  }
  const { Pool } = await import('pg');
  const { PgRepository } = await import('./infra/repositories/PgRepository');
  const { migrate } = await import('./infra/db/migrate');
  const pool = new Pool({ connectionString: config.databaseUrl, ssl: config.pgSsl ? { rejectUnauthorized: false } : undefined, max: 10 });
  await migrate(pool);
  console.log('🗄️  PostgreSQL connected, migrations applied.');
  return new PgRepository(pool);
}

async function main() {
  const repo = await createRepository();
  const users = new UserService(repo);

  const app = express();
  app.set('trust proxy', 1);
  app.disable('x-powered-by');
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('X-Frame-Options', 'DENY');
    next();
  });

  const server = http.createServer(app);
  const io = createSocketServer(server);
  const rooms = new RoomManager(repo, new SocketBroadcaster(io), new StatsService(repo));
  rooms.startLoop();
  attachHandlers(io, rooms, users);

  app.use('/api', apiRouter({ rooms, users, repo }));

  if (config.serveWeb) {
    const next = (await import('next')).default;
    const web = next({ dev: config.dev, dir: path.resolve(__dirname, '../../web') });
    await web.prepare();
    const handle = web.getRequestHandler();
    app.all('*', (req, res) => handle(req, res));
  }

  server.listen(config.port, config.host, () => {
    console.log(`🎩 MAFIA NIGHT running on http://localhost:${config.port}`);
  });

  const shutdown = () => {
    rooms.stopLoop();
    io.close();
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 3000).unref();
  };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
