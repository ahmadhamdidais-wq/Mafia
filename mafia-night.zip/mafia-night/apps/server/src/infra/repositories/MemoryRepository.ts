import { levelFromXp, type PlayerProfile } from '@mafia/shared';
import { EMPTY_DELTA, type CumulativeStats, type Repository, type StatsDelta } from './Repository';

/** Used when DATABASE_URL is not set (local play, tests). Data resets on restart. */
export class MemoryRepository implements Repository {
  readonly kind = 'memory' as const;
  private users = new Map<string, { id: string; name: string; tokenHash: string }>();
  private byToken = new Map<string, string>();
  private stats = new Map<string, CumulativeStats>();
  private achievements = new Map<string, Map<string, string>>();
  readonly gameLog: { gameId: string; type: string; payload: unknown }[] = [];

  async createUser(u: { id: string; name: string; tokenHash: string }) {
    this.users.set(u.id, u);
    this.byToken.set(u.tokenHash, u.id);
  }
  async findUserByTokenHash(hash: string) {
    const id = this.byToken.get(hash);
    const u = id ? this.users.get(id) : undefined;
    return u ? { id: u.id, name: u.name } : null;
  }
  async updateUserName(id: string, name: string) {
    const u = this.users.get(id);
    if (u) u.name = name;
  }
  async createRoom() {}
  async addRoomPlayer() {}
  async removeRoomPlayer() {}
  async createGame(g: { id: string }) {
    this.gameLog.push({ gameId: g.id, type: 'CREATED', payload: g });
  }
  async logEvent(gameId: string, _round: number, type: string, payload: unknown) {
    this.gameLog.push({ gameId, type, payload });
    if (this.gameLog.length > 5000) this.gameLog.splice(0, 1000);
  }
  async recordVote() {}
  async finishGame() {}

  async applyStats(userId: string, delta: StatsDelta) {
    const cur = { ...(this.stats.get(userId) ?? EMPTY_DELTA) };
    for (const k of Object.keys(delta) as (keyof StatsDelta)[]) cur[k] += delta[k];
    this.stats.set(userId, cur);
    return cur;
  }
  async unlockAchievements(userId: string, keys: string[]) {
    const map = this.achievements.get(userId) ?? new Map<string, string>();
    for (const k of keys) if (!map.has(k)) map.set(k, new Date().toISOString());
    this.achievements.set(userId, map);
  }
  async getProfile(userId: string): Promise<PlayerProfile | null> {
    const u = this.users.get(userId);
    if (!u) return null;
    const s = this.stats.get(userId) ?? EMPTY_DELTA;
    const { xp, ...stats } = s;
    return {
      id: u.id,
      name: u.name,
      xp,
      level: levelFromXp(xp),
      stats,
      achievements: [...(this.achievements.get(userId) ?? new Map()).entries()].map(([key, unlockedAt]) => ({ key, unlockedAt })),
    };
  }
}
