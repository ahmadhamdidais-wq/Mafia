import type { Pool } from 'pg';
import { levelFromXp, type PlayerProfile, type Role, type RoomSettings, type Winner } from '@mafia/shared';
import type { CumulativeStats, Repository, StatsDelta } from './Repository';

export class PgRepository implements Repository {
  readonly kind = 'postgres' as const;
  constructor(private readonly pool: Pool) {}

  async createUser(u: { id: string; name: string; tokenHash: string }) {
    await this.pool.query('INSERT INTO users(id, name, token_hash) VALUES ($1,$2,$3)', [u.id, u.name, u.tokenHash]);
  }

  async findUserByTokenHash(tokenHash: string) {
    const { rows } = await this.pool.query<{ id: string; name: string }>(
      'UPDATE users SET last_seen = now() WHERE token_hash = $1 RETURNING id, name',
      [tokenHash],
    );
    return rows[0] ?? null;
  }

  async updateUserName(id: string, name: string) {
    await this.pool.query('UPDATE users SET name = $2 WHERE id = $1', [id, name]);
  }

  async createRoom(code: string, hostId: string) {
    await this.pool.query('INSERT INTO rooms(code, host_id) VALUES ($1,$2) ON CONFLICT (code) DO UPDATE SET host_id = $2', [code, hostId]);
  }

  async addRoomPlayer(code: string, userId: string) {
    await this.pool.query(
      `INSERT INTO room_players(room_code, user_id) VALUES ($1,$2)
       ON CONFLICT (room_code, user_id) DO UPDATE SET left_at = NULL`,
      [code, userId],
    );
  }

  async removeRoomPlayer(code: string, userId: string) {
    await this.pool.query('UPDATE room_players SET left_at = now() WHERE room_code = $1 AND user_id = $2', [code, userId]);
  }

  async createGame(g: { id: string; roomCode: string; settings: RoomSettings; players: { userId: string; role: Role }[] }) {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      await client.query('INSERT INTO games(id, room_code, settings) VALUES ($1,$2,$3)', [g.id, g.roomCode, JSON.stringify(g.settings)]);
      for (const p of g.players) {
        await client.query('INSERT INTO game_players(game_id, user_id, role) VALUES ($1,$2,$3)', [g.id, p.userId, p.role]);
      }
      await client.query('COMMIT');
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  }

  async logEvent(gameId: string, round: number, type: string, payload: unknown) {
    await this.pool.query('INSERT INTO game_events(game_id, round, type, payload) VALUES ($1,$2,$3,$4)', [
      gameId,
      round,
      type,
      JSON.stringify(payload),
    ]);
  }

  async recordVote(gameId: string, round: number, voterId: string, targetId: string | null) {
    await this.pool.query(
      'INSERT INTO votes(game_id, round, voter_id, target_id) VALUES ($1,$2,$3,$4) ON CONFLICT DO NOTHING',
      [gameId, round, voterId, targetId],
    );
  }

  async finishGame(gameId: string, winner: Winner, players: { userId: string; alive: boolean; won: boolean }[]) {
    await this.pool.query('UPDATE games SET winner = $2, ended_at = now() WHERE id = $1', [gameId, winner]);
    for (const p of players) {
      await this.pool.query('UPDATE game_players SET alive = $3, won = $4 WHERE game_id = $1 AND user_id = $2', [
        gameId,
        p.userId,
        p.alive,
        p.won,
      ]);
    }
  }

  async applyStats(userId: string, d: StatsDelta): Promise<CumulativeStats> {
    const { rows } = await this.pool.query(
      `INSERT INTO player_stats AS s (user_id, games_played, wins, losses, mafia_wins, citizen_wins, detective_wins,
          doctor_saves, detective_finds, players_eliminated, xp)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
       ON CONFLICT (user_id) DO UPDATE SET
         games_played = s.games_played + EXCLUDED.games_played,
         wins = s.wins + EXCLUDED.wins,
         losses = s.losses + EXCLUDED.losses,
         mafia_wins = s.mafia_wins + EXCLUDED.mafia_wins,
         citizen_wins = s.citizen_wins + EXCLUDED.citizen_wins,
         detective_wins = s.detective_wins + EXCLUDED.detective_wins,
         doctor_saves = s.doctor_saves + EXCLUDED.doctor_saves,
         detective_finds = s.detective_finds + EXCLUDED.detective_finds,
         players_eliminated = s.players_eliminated + EXCLUDED.players_eliminated,
         xp = s.xp + EXCLUDED.xp
       RETURNING *`,
      [userId, d.gamesPlayed, d.wins, d.losses, d.mafiaWins, d.citizenWins, d.detectiveWins, d.doctorSaves, d.detectiveFinds, d.playersEliminated, d.xp],
    );
    return rowToStats(rows[0]);
  }

  async unlockAchievements(userId: string, keys: string[]) {
    for (const key of keys) {
      await this.pool.query('INSERT INTO achievements(user_id, key) VALUES ($1,$2) ON CONFLICT DO NOTHING', [userId, key]);
    }
  }

  async getProfile(userId: string): Promise<PlayerProfile | null> {
    const user = await this.pool.query<{ id: string; name: string }>('SELECT id, name FROM users WHERE id = $1', [userId]);
    if (!user.rows[0]) return null;
    const stats = await this.pool.query('SELECT * FROM player_stats WHERE user_id = $1', [userId]);
    const ach = await this.pool.query<{ key: string; unlocked_at: Date }>(
      'SELECT key, unlocked_at FROM achievements WHERE user_id = $1 ORDER BY unlocked_at',
      [userId],
    );
    const { xp, ...rest } = rowToStats(stats.rows[0]);
    return {
      id: user.rows[0].id,
      name: user.rows[0].name,
      xp,
      level: levelFromXp(xp),
      stats: rest,
      achievements: ach.rows.map((a) => ({ key: a.key, unlockedAt: a.unlocked_at.toISOString() })),
    };
  }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function rowToStats(r: any): CumulativeStats {
  return {
    gamesPlayed: r?.games_played ?? 0,
    wins: r?.wins ?? 0,
    losses: r?.losses ?? 0,
    mafiaWins: r?.mafia_wins ?? 0,
    citizenWins: r?.citizen_wins ?? 0,
    detectiveWins: r?.detective_wins ?? 0,
    doctorSaves: r?.doctor_saves ?? 0,
    detectiveFinds: r?.detective_finds ?? 0,
    playersEliminated: r?.players_eliminated ?? 0,
    xp: r?.xp ?? 0,
  };
}
