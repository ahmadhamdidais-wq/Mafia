import type { PlayerProfile, Role, RoomSettings, Winner } from '@mafia/shared';

export interface StatsDelta {
  gamesPlayed: number;
  wins: number;
  losses: number;
  mafiaWins: number;
  citizenWins: number;
  detectiveWins: number;
  doctorSaves: number;
  detectiveFinds: number;
  playersEliminated: number;
  xp: number;
}

export type CumulativeStats = Omit<StatsDelta, never>;

/** Persistence port. The game never blocks on it; failures are logged, not fatal. */
export interface Repository {
  readonly kind: 'postgres' | 'memory';
  createUser(u: { id: string; name: string; tokenHash: string }): Promise<void>;
  findUserByTokenHash(tokenHash: string): Promise<{ id: string; name: string } | null>;
  updateUserName(id: string, name: string): Promise<void>;

  createRoom(code: string, hostId: string): Promise<void>;
  addRoomPlayer(code: string, userId: string): Promise<void>;
  removeRoomPlayer(code: string, userId: string): Promise<void>;

  createGame(g: { id: string; roomCode: string; settings: RoomSettings; players: { userId: string; role: Role }[] }): Promise<void>;
  logEvent(gameId: string, round: number, type: string, payload: unknown): Promise<void>;
  recordVote(gameId: string, round: number, voterId: string, targetId: string | null): Promise<void>;
  finishGame(gameId: string, winner: Winner, players: { userId: string; alive: boolean; won: boolean }[]): Promise<void>;

  /** Adds delta and returns the new cumulative stats. */
  applyStats(userId: string, delta: StatsDelta): Promise<CumulativeStats>;
  unlockAchievements(userId: string, keys: string[]): Promise<void>;
  getProfile(userId: string): Promise<PlayerProfile | null>;
}

export const EMPTY_DELTA: StatsDelta = {
  gamesPlayed: 0,
  wins: 0,
  losses: 0,
  mafiaWins: 0,
  citizenWins: 0,
  detectiveWins: 0,
  doctorSaves: 0,
  detectiveFinds: 0,
  playersEliminated: 0,
  xp: 0,
};
