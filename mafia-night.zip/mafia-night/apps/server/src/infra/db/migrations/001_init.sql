-- MAFIA NIGHT initial schema

CREATE TABLE IF NOT EXISTS users (
  id          UUID PRIMARY KEY,
  name        VARCHAR(32) NOT NULL,
  token_hash  CHAR(64) NOT NULL UNIQUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_seen   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS rooms (
  code        VARCHAR(8) PRIMARY KEY,
  host_id     UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS room_players (
  room_code   VARCHAR(8) NOT NULL REFERENCES rooms(code) ON DELETE CASCADE,
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  joined_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  left_at     TIMESTAMPTZ,
  PRIMARY KEY (room_code, user_id)
);

CREATE TABLE IF NOT EXISTS games (
  id          UUID PRIMARY KEY,
  room_code   VARCHAR(8) NOT NULL REFERENCES rooms(code) ON DELETE CASCADE,
  settings    JSONB NOT NULL,
  winner      VARCHAR(8),
  started_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  ended_at    TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS games_room_idx ON games(room_code);

CREATE TABLE IF NOT EXISTS game_players (
  game_id     UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role        VARCHAR(16) NOT NULL,
  alive       BOOLEAN NOT NULL DEFAULT true,
  won         BOOLEAN,
  PRIMARY KEY (game_id, user_id)
);
CREATE INDEX IF NOT EXISTS game_players_user_idx ON game_players(user_id);

CREATE TABLE IF NOT EXISTS game_events (
  id          BIGSERIAL PRIMARY KEY,
  game_id     UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  round       INT NOT NULL,
  type        VARCHAR(32) NOT NULL,
  payload     JSONB NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS game_events_game_idx ON game_events(game_id);

CREATE TABLE IF NOT EXISTS votes (
  game_id     UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  round       INT NOT NULL,
  voter_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_id   UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (game_id, round, voter_id)   -- one vote per player per round, enforced by the DB too
);

CREATE TABLE IF NOT EXISTS player_stats (
  user_id             UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  games_played        INT NOT NULL DEFAULT 0,
  wins                INT NOT NULL DEFAULT 0,
  losses              INT NOT NULL DEFAULT 0,
  mafia_wins          INT NOT NULL DEFAULT 0,
  citizen_wins        INT NOT NULL DEFAULT 0,
  detective_wins      INT NOT NULL DEFAULT 0,
  doctor_saves        INT NOT NULL DEFAULT 0,
  detective_finds     INT NOT NULL DEFAULT 0,
  players_eliminated  INT NOT NULL DEFAULT 0,
  xp                  INT NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS achievements (
  user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key          VARCHAR(32) NOT NULL,
  unlocked_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, key)
);
