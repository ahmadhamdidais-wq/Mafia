// Must be the first import: loads .env and fixes NODE_ENV before anything reads it.
import path from 'node:path';
import dotenv from 'dotenv';

dotenv.config({ path: path.resolve(__dirname, '../../../.env') });
dotenv.config(); // also allow a .env next to where the command runs
if (process.argv.includes('--prod')) (process.env as Record<string, string>).NODE_ENV = 'production';
