export const config = {
  port: Number(process.env.PORT ?? 3000),
  host: process.env.HOST ?? '0.0.0.0',
  dev: process.env.NODE_ENV !== 'production',
  publicUrl: process.env.PUBLIC_URL?.replace(/\/$/, '') || null,
  databaseUrl: process.env.DATABASE_URL || null,
  pgSsl: process.env.PGSSL === 'true',
  /** Serve the Next.js site from this same process (recommended: one URL, one deploy). */
  serveWeb: process.env.SERVE_WEB !== 'false',
  /** Only needed if the website is hosted separately (SERVE_WEB=false). */
  corsOrigin: process.env.CORS_ORIGIN?.split(',') ?? [],
};
