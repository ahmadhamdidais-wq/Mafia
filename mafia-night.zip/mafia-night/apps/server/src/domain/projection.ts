import { LIMITS, type GameView, type PlayerView, type Role } from '@mafia/shared';
import type { Room } from './Room';

/**
 * Builds the view of the room for ONE player. This is the single place that decides
 * what a client may know — secret roles, night choices and detective results never
 * leave the server unless this function includes them for that specific viewer.
 */
export function projectFor(room: Room, viewerId: string, now: number): GameView {
  const engine = room.engine;
  const viewerRole: Role | null = engine?.roleOf(viewerId) ?? null;
  const viewerAlive = engine ? (engine.players.get(viewerId)?.alive ?? false) : true;
  const gameOver = engine?.phase === 'GAME_OVER';

  const canSeeRole = (targetId: string, targetRole: Role, targetAlive: boolean): boolean => {
    if (targetId === viewerId) return true;
    if (gameOver) return true;
    if (viewerRole === 'MAFIA' && targetRole === 'MAFIA') return true;
    if (!targetAlive && room.settings.revealRoleOnDeath) return true;
    return false;
  };

  const members = [...room.members.values()].sort((a, b) => a.joinedAt - b.joinedAt);
  const players: PlayerView[] = members.map((m) => {
    const ep = engine?.players.get(m.id);
    const view: PlayerView = {
      id: m.id,
      name: m.name,
      avatar: m.avatar,
      isHost: m.id === room.hostId,
      ready: m.ready || m.id === room.hostId,
      connected: m.connected,
      alive: ep ? ep.alive : true,
    };
    if (ep) {
      if (!ep.alive) view.deathCause = ep.deathCause;
      if (canSeeRole(m.id, ep.role, ep.alive)) view.role = ep.role;
    }
    return view;
  });

  // Players who left mid-game are no longer members but still matter for the game-over screen.
  if (engine) {
    for (const ep of engine.players.values()) {
      if (room.members.has(ep.id)) continue;
      const view: PlayerView = {
        id: ep.id,
        name: room.departed.get(ep.id)?.name ?? '—',
        avatar: room.departed.get(ep.id)?.avatar ?? '👤',
        isHost: false,
        ready: false,
        connected: false,
        alive: ep.alive,
        deathCause: ep.deathCause,
      };
      if (canSeeRole(ep.id, ep.role, ep.alive)) view.role = ep.role;
      players.push(view);
    }
  }

  const view: GameView = {
    roomCode: room.code,
    hostId: room.hostId,
    phase: room.phase,
    round: engine?.round ?? 0,
    endsAt: engine?.endsAt ?? null,
    serverNow: now,
    settings: room.settings,
    players,
    minPlayers: LIMITS.MIN_PLAYERS,
    maxPlayers: LIMITS.MAX_PLAYERS,
    me: {
      id: viewerId,
      role: viewerRole,
      alive: viewerAlive,
      isHost: viewerId === room.hostId,
      ackedRole: engine?.players.get(viewerId)?.ackedRole ?? false,
    },
  };

  if (!engine) return view;

  if (viewerRole === 'MAFIA') view.mafiaTeam = engine.mafiaIds();

  if (engine.phase === 'ROLE_REVEAL') view.ackCount = engine.ackState();

  if (engine.phase === 'NIGHT') {
    const canAct = viewerAlive && (viewerRole === 'MAFIA' || viewerRole === 'DOCTOR' || viewerRole === 'DETECTIVE');
    const choice = engine.nightChoiceOf(viewerId);
    view.night = { canAct, myTarget: choice.target, locked: choice.locked };
    if (viewerRole === 'MAFIA' && viewerAlive) view.night.mafiaVotes = engine.mafiaVoteList();
    if (viewerRole === 'DOCTOR') view.night.blockedTargetId = engine.doctorBlockedTarget();
  }

  if (engine.phase === 'DISCUSSION') {
    view.discussion = { ...engine.skipState(viewerId), eligible: engine.alive().length };
  }

  if (engine.phase === 'VOTING') {
    view.voting = {
      votedCount: engine.votedCount(),
      eligible: engine.alive().length,
      myVote: engine.voteOf(viewerId),
    };
  }

  if (engine.lastNight) view.lastNight = engine.lastNight;
  if (engine.lastVote && (engine.phase === 'RESULT' || engine.phase === 'GAME_OVER')) view.lastVote = engine.lastVote;
  if (viewerRole === 'DETECTIVE') view.investigations = engine.investigationsOf(viewerId);

  if (gameOver && engine.winner) {
    view.winner = engine.winner;
    view.finalRoles = [...engine.players.values()].map((p) => ({ id: p.id, role: p.role }));
  }

  return view;
}
