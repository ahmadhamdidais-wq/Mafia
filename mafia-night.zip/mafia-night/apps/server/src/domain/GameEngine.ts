import { FIXED_PHASE_SECONDS, phaseSeconds } from '@mafia/shared';
import type {
  DeathCause,
  Investigation,
  Phase,
  Role,
  RoomSettings,
  VoteTallyEntry,
  Winner,
} from '@mafia/shared';
import { assignRoles } from './roles';
import { pick, type Rng } from '../infra/random';

/** Thrown for any rejected player action. Message is user-facing (Arabic). */
export class GameError extends Error {}

export interface EnginePlayer {
  id: string;
  role: Role;
  alive: boolean;
  ackedRole: boolean;
  deathCause?: DeathCause;
  diedRound?: number;
}

export type DomainEvent =
  | { type: 'PHASE'; phase: Phase; round: number }
  | { type: 'NIGHT_ACTION'; actorId: string; role: Role; targetId: string; round: number }
  | { type: 'INVESTIGATION'; detectiveId: string; targetId: string; isMafia: boolean; round: number }
  | { type: 'SAVE'; doctorId: string; targetId: string; round: number }
  | { type: 'VOTE'; voterId: string; targetId: string | null; round: number }
  | { type: 'DEATH'; playerId: string; cause: DeathCause; role: Role; round: number; creditIds: string[] }
  | { type: 'GAME_OVER'; winner: Winner };

export const FIXED_DURATIONS = FIXED_PHASE_SECONDS;

const NIGHT_ROLES: Role[] = ['MAFIA', 'DOCTOR', 'DETECTIVE'];

/**
 * Pure game state machine. It never touches sockets, timers or the database:
 * the room manager calls `tick(now)` periodically and reads `drainEvents()`.
 * Phases advance by deadline (`endsAt`) or early when everyone has acted.
 */
export class GameEngine {
  readonly players = new Map<string, EnginePlayer>();
  phase: Phase = 'ROLE_REVEAL';
  round = 0;
  endsAt: number | null = null;

  private mafiaVotes = new Map<string, string>();
  private doctorTarget: string | null = null;
  private detectiveTarget: string | null = null;
  private lastDoctorTarget: string | null = null;
  private votes = new Map<string, string | 'SKIP'>();
  private skips = new Set<string>();
  private investigations = new Map<string, Investigation[]>();
  /** Total votes received during the whole game (for the "deceiver" achievement). */
  readonly votesReceived = new Map<string, number>();

  lastNight: { victimId: string | null; strange: boolean } | null = null;
  lastVote: { tally: VoteTallyEntry[]; skipCount: number; eliminatedId: string | null } | null = null;
  pendingWinner: Winner | null = null;
  winner: Winner | null = null;

  private events: DomainEvent[] = [];

  constructor(
    playerIds: string[],
    readonly settings: RoomSettings,
    private readonly clock: () => number,
    private readonly rng: Rng,
  ) {
    const roles = assignRoles(playerIds, rng);
    for (const id of playerIds) {
      this.players.set(id, { id, role: roles.get(id)!, alive: true, ackedRole: false });
    }
    this.enter('ROLE_REVEAL');
  }

  // ---------------------------------------------------------------- queries

  drainEvents(): DomainEvent[] {
    const out = this.events;
    this.events = [];
    return out;
  }

  alive(): EnginePlayer[] {
    return [...this.players.values()].filter((p) => p.alive);
  }

  roleOf(id: string): Role | undefined {
    return this.players.get(id)?.role;
  }

  mafiaIds(): string[] {
    return [...this.players.values()].filter((p) => p.role === 'MAFIA').map((p) => p.id);
  }

  nightChoiceOf(id: string): { target: string | null; locked: boolean } {
    const role = this.roleOf(id);
    if (role === 'MAFIA') return { target: this.mafiaVotes.get(id) ?? null, locked: false };
    if (role === 'DOCTOR') return { target: this.doctorTarget, locked: this.doctorTarget !== null };
    if (role === 'DETECTIVE') return { target: this.detectiveTarget, locked: this.detectiveTarget !== null };
    return { target: null, locked: false };
  }

  mafiaVoteList(): { voterId: string; targetId: string }[] {
    return [...this.mafiaVotes.entries()].map(([voterId, targetId]) => ({ voterId, targetId }));
  }

  doctorBlockedTarget(): string | null {
    return this.lastDoctorTarget;
  }

  investigationsOf(id: string): Investigation[] {
    return this.investigations.get(id) ?? [];
  }

  voteOf(id: string): string | null {
    return this.votes.get(id) ?? null;
  }

  votedCount(): number {
    return this.votes.size;
  }

  skipState(id: string) {
    return { skipCount: this.skips.size, iSkipped: this.skips.has(id) };
  }

  ackState() {
    const all = [...this.players.values()];
    return { acked: all.filter((p) => p.ackedRole).length, total: all.length };
  }

  // ---------------------------------------------------------------- clock

  /** Advances the phase if its deadline passed. Returns true if anything changed. */
  tick(now = this.clock()): boolean {
    if (this.endsAt !== null && now >= this.endsAt) {
      this.advance();
      return true;
    }
    return false;
  }

  private enter(phase: Phase) {
    this.phase = phase;
    const seconds = this.durationOf(phase);
    this.endsAt = seconds === null ? null : this.clock() + seconds * 1000;
    if (phase === 'NIGHT') {
      this.mafiaVotes.clear();
      this.doctorTarget = null;
      this.detectiveTarget = null;
    }
    if (phase === 'DISCUSSION') this.skips.clear();
    if (phase === 'VOTING') this.votes.clear();
    this.events.push({ type: 'PHASE', phase, round: this.round });
  }

  private durationOf(phase: Phase): number | null {
    return phase === 'LOBBY' || phase === 'GAME_OVER' ? null : phaseSeconds(phase, this.settings);
  }

  private advance() {
    switch (this.phase) {
      case 'ROLE_REVEAL':
        this.round = 1;
        this.enter('NIGHT');
        break;
      case 'NIGHT':
        this.resolveNight();
        this.enter('DAY');
        break;
      case 'DAY':
        if (this.pendingWinner) this.finish(this.pendingWinner);
        else this.enter('DISCUSSION');
        break;
      case 'DISCUSSION':
        this.enter('VOTING');
        break;
      case 'VOTING':
        this.resolveVote();
        this.enter('RESULT');
        break;
      case 'RESULT':
        if (this.pendingWinner) this.finish(this.pendingWinner);
        else {
          this.round += 1;
          this.enter('NIGHT');
        }
        break;
      default:
        break;
    }
  }

  // ---------------------------------------------------------------- actions

  private requirePhase(phase: Phase) {
    if (this.phase !== phase) throw new GameError('هذا الإجراء غير متاح الآن.');
  }

  private requireAlive(id: string): EnginePlayer {
    const p = this.players.get(id);
    if (!p) throw new GameError('أنت لست لاعبًا في هذه المباراة.');
    if (!p.alive) throw new GameError('اللاعبون الموتى لا يستطيعون فعل ذلك.');
    return p;
  }

  private requireAliveTarget(targetId: string): EnginePlayer {
    const t = this.players.get(targetId);
    if (!t || !t.alive) throw new GameError('اختيار غير صالح.');
    return t;
  }

  ackRole(playerId: string) {
    this.requirePhase('ROLE_REVEAL');
    const p = this.players.get(playerId);
    if (!p) throw new GameError('أنت لست لاعبًا في هذه المباراة.');
    p.ackedRole = true;
    if ([...this.players.values()].every((x) => x.ackedRole || !x.alive)) this.advance();
  }

  nightAction(actorId: string, targetId: string) {
    this.requirePhase('NIGHT');
    const actor = this.requireAlive(actorId);
    if (!NIGHT_ROLES.includes(actor.role)) throw new GameError('ليس لديك أي قدرة ليلية.');
    const target = this.requireAliveTarget(targetId);

    switch (actor.role) {
      case 'MAFIA':
        if (target.role === 'MAFIA') throw new GameError('لا يمكنك استهداف أحد أفراد المافيا.');
        this.mafiaVotes.set(actorId, targetId);
        break;
      case 'DOCTOR':
        if (this.doctorTarget !== null) throw new GameError('لقد اخترت بالفعل هذه الليلة.');
        if (targetId === this.lastDoctorTarget) throw new GameError('لا يمكنك حماية نفس اللاعب ليلتين متتاليتين.');
        this.doctorTarget = targetId;
        break;
      case 'DETECTIVE':
        if (this.detectiveTarget !== null) throw new GameError('لقد حققت بالفعل هذه الليلة.');
        if (targetId === actorId) throw new GameError('لا يمكنك التحقيق مع نفسك.');
        this.detectiveTarget = targetId;
        break;
    }
    this.events.push({ type: 'NIGHT_ACTION', actorId, role: actor.role, targetId, round: this.round });
  }

  discussionSkip(playerId: string) {
    this.requirePhase('DISCUSSION');
    this.requireAlive(playerId);
    this.skips.add(playerId);
    if (this.skips.size >= this.alive().length) this.advance();
  }

  castVote(voterId: string, targetId: string | 'SKIP') {
    this.requirePhase('VOTING');
    this.requireAlive(voterId);
    if (this.votes.has(voterId)) throw new GameError('لقد صوّت بالفعل.');
    if (targetId !== 'SKIP') {
      this.requireAliveTarget(targetId);
      if (targetId === voterId) throw new GameError('لا يمكنك التصويت ضد نفسك.');
      this.votesReceived.set(targetId, (this.votesReceived.get(targetId) ?? 0) + 1);
    }
    this.votes.set(voterId, targetId);
    this.events.push({ type: 'VOTE', voterId, targetId: targetId === 'SKIP' ? null : targetId, round: this.round });
    this.checkVotingComplete();
  }

  private checkVotingComplete() {
    const aliveIds = new Set(this.alive().map((p) => p.id));
    const counted = [...this.votes.keys()].filter((id) => aliveIds.has(id)).length;
    if (this.phase === 'VOTING' && counted >= aliveIds.size) this.advance();
  }

  /** A player abandoned the game (disconnect grace expired or left). */
  removePlayer(playerId: string) {
    const p = this.players.get(playerId);
    if (!p || !p.alive || this.phase === 'GAME_OVER') return;
    this.kill(p, 'LEFT', []);
    this.mafiaVotes.delete(playerId);
    const winner = this.computeWinner();
    if (winner) {
      this.finish(winner);
      return;
    }
    if (this.phase === 'VOTING') this.checkVotingComplete();
    else if (this.phase === 'DISCUSSION' && this.skips.size >= this.alive().length) this.advance();
    else if (this.phase === 'ROLE_REVEAL' && [...this.players.values()].every((x) => x.ackedRole || !x.alive))
      this.advance();
  }

  // ---------------------------------------------------------------- resolution

  private resolveNight() {
    // Mafia target: plurality of alive mafia votes on still-alive targets; ties broken randomly.
    const tally = new Map<string, number>();
    for (const [voterId, targetId] of this.mafiaVotes) {
      if (!this.players.get(voterId)?.alive || !this.players.get(targetId)?.alive) continue;
      tally.set(targetId, (tally.get(targetId) ?? 0) + 1);
    }
    let killTarget: string | null = null;
    if (tally.size > 0) {
      const max = Math.max(...tally.values());
      killTarget = pick([...tally.entries()].filter(([, n]) => n === max).map(([id]) => id), this.rng);
    }

    // Detective learns the truth about their target, privately.
    const detective = [...this.players.values()].find((p) => p.role === 'DETECTIVE' && p.alive);
    if (detective && this.detectiveTarget) {
      const isMafia = this.players.get(this.detectiveTarget)?.role === 'MAFIA';
      const entry: Investigation = { round: this.round, targetId: this.detectiveTarget, isMafia };
      this.investigations.set(detective.id, [...this.investigationsOf(detective.id), entry]);
      this.events.push({ type: 'INVESTIGATION', detectiveId: detective.id, ...entry });
    }

    let victimId: string | null = null;
    let strange = false;
    if (killTarget) {
      const doctor = [...this.players.values()].find((p) => p.role === 'DOCTOR' && p.alive);
      if (doctor && this.doctorTarget === killTarget) {
        strange = true;
        this.events.push({ type: 'SAVE', doctorId: doctor.id, targetId: killTarget, round: this.round });
      } else {
        const credit = this.mafiaVoteList()
          .filter((v) => v.targetId === killTarget)
          .map((v) => v.voterId);
        this.kill(this.players.get(killTarget)!, 'MAFIA', credit);
        victimId = killTarget;
      }
    }
    this.lastDoctorTarget = this.doctorTarget;
    this.lastNight = { victimId, strange };
    this.pendingWinner = this.computeWinner();
  }

  private resolveVote() {
    const counts = new Map<string, number>();
    let skipCount = 0;
    for (const [voterId, target] of this.votes) {
      if (!this.players.get(voterId)?.alive) continue;
      if (target === 'SKIP') skipCount++;
      else if (this.players.get(target)?.alive) counts.set(target, (counts.get(target) ?? 0) + 1);
    }
    const tally = [...counts.entries()]
      .map(([targetId, count]) => ({ targetId, count }))
      .sort((a, b) => b.count - a.count);

    let eliminatedId: string | null = null;
    const top = tally[0];
    const isUniqueTop = top && (tally.length === 1 || tally[1].count < top.count);
    if (top && isUniqueTop && top.count > skipCount) {
      eliminatedId = top.targetId;
      const credit = [...this.votes.entries()].filter(([, t]) => t === eliminatedId).map(([v]) => v);
      this.kill(this.players.get(eliminatedId)!, 'VOTE', credit);
    }
    this.lastVote = { tally, skipCount, eliminatedId };
    this.pendingWinner = this.computeWinner();
  }

  private kill(p: EnginePlayer, cause: DeathCause, creditIds: string[]) {
    p.alive = false;
    p.deathCause = cause;
    p.diedRound = this.round;
    this.events.push({ type: 'DEATH', playerId: p.id, cause, role: p.role, round: this.round, creditIds });
  }

  computeWinner(): Winner | null {
    const alive = this.alive();
    const mafia = alive.filter((p) => p.role === 'MAFIA').length;
    const town = alive.length - mafia;
    if (mafia === 0) return 'TOWN';
    if (mafia >= town) return 'MAFIA';
    return null;
  }

  private finish(winner: Winner) {
    this.winner = winner;
    this.pendingWinner = null;
    this.enter('GAME_OVER');
    this.events.push({ type: 'GAME_OVER', winner });
  }
}
