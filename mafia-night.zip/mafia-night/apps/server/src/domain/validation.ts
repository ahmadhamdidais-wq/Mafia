import { LIMITS, ROOM_CODE_REGEX } from '@mafia/shared';

// Control characters and bidi overrides (used for spoofing text direction).
const UNSAFE_CHARS = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u200E\u200F\u202A-\u202E\u2066-\u2069<>]/g;

export function sanitizeName(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const name = raw.replace(UNSAFE_CHARS, '').replace(/\s+/g, ' ').trim();
  if ([...name].length < LIMITS.NAME_MIN || [...name].length > LIMITS.NAME_MAX) return null;
  return name;
}

export function sanitizeChat(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const text = raw
    .replace(UNSAFE_CHARS, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
    .slice(0, LIMITS.CHAT_MAX);
  return text.length ? text : null;
}

export function normalizeRoomCode(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const code = raw.trim().toUpperCase();
  return ROOM_CODE_REGEX.test(code) ? code : null;
}

export function isNonEmptyString(v: unknown, max = 200): v is string {
  return typeof v === 'string' && v.length > 0 && v.length <= max;
}
