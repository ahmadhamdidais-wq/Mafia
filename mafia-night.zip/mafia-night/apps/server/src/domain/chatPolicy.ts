import type { ChatChannel, Phase } from '@mafia/shared';
import type { Room } from './Room';

const DAYTIME: Phase[] = ['DAY', 'DISCUSSION', 'VOTING', 'RESULT'];

function isAlive(room: Room, id: string) {
  return room.engine?.players.get(id)?.alive ?? false;
}
function isMafia(room: Room, id: string) {
  return room.engine?.roleOf(id) === 'MAFIA';
}

/** Can `senderId` write to `channel` right now? */
export function canSend(room: Room, senderId: string, channel: ChatChannel): boolean {
  if (!room.members.has(senderId)) return false;
  const phase = room.phase;
  switch (channel) {
    case 'LOBBY':
      return phase === 'LOBBY' || phase === 'GAME_OVER';
    case 'PUBLIC':
      return DAYTIME.includes(phase) && isAlive(room, senderId);
    case 'MAFIA':
      return phase === 'NIGHT' && isAlive(room, senderId) && isMafia(room, senderId);
    case 'DEAD':
      return room.inGame && !!room.engine?.players.has(senderId) && !isAlive(room, senderId);
  }
}

/** Can `viewerId` read messages on `channel`? */
export function canRead(room: Room, viewerId: string, channel: ChatChannel): boolean {
  if (!room.members.has(viewerId)) return false;
  switch (channel) {
    case 'LOBBY':
    case 'PUBLIC':
      return true;
    case 'MAFIA':
      return isMafia(room, viewerId) && isAlive(room, viewerId);
    case 'DEAD':
      return !!room.engine?.players.has(viewerId) && !isAlive(room, viewerId);
  }
}

/**
 * Voice channel a member should be in right now (WebRTC-ready policy, same rules as text).
 * PUBLIC open during the day, MAFIA private at night, DEAD always for the dead.
 */
export function voiceChannelFor(room: Room, id: string): ChatChannel | null {
  if (!room.engine || room.phase === 'GAME_OVER') return 'LOBBY';
  if (!room.engine.players.has(id)) return null;
  if (!isAlive(room, id)) return 'DEAD';
  if (room.phase === 'NIGHT') return isMafia(room, id) ? 'MAFIA' : null;
  return DAYTIME.includes(room.phase) ? 'PUBLIC' : null;
}
