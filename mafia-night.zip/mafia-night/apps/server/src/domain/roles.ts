import type { Role } from '@mafia/shared';
import { LIMITS } from '@mafia/shared';
import { shuffle, type Rng } from '../infra/random';

/**
 * Role distribution table. Edit this to rebalance — each row maps a player-count
 * range to the special roles; everyone else becomes a CITIZEN.
 */
export interface DistributionRow {
  min: number;
  max: number;
  roles: Partial<Record<Exclude<Role, 'CITIZEN'>, number>>;
}

export const ROLE_DISTRIBUTION: DistributionRow[] = [
  { min: 5, max: 5, roles: { MAFIA: 1, DOCTOR: 1, DETECTIVE: 1 } },
  { min: 6, max: 7, roles: { MAFIA: 2, DOCTOR: 1, DETECTIVE: 1 } },
  { min: 8, max: 10, roles: { MAFIA: 2, DOCTOR: 1, DETECTIVE: 1 } },
  { min: 11, max: 15, roles: { MAFIA: 3, DOCTOR: 1, DETECTIVE: 1 } },
];

export function rolesForCount(count: number, table = ROLE_DISTRIBUTION): Role[] {
  if (count < LIMITS.MIN_PLAYERS || count > LIMITS.MAX_PLAYERS) {
    throw new Error(`Unsupported player count: ${count}`);
  }
  const row = table.find((r) => count >= r.min && count <= r.max);
  if (!row) throw new Error(`No distribution row for ${count} players`);
  const roles: Role[] = [];
  for (const [role, n] of Object.entries(row.roles) as [Role, number][]) {
    for (let i = 0; i < n; i++) roles.push(role);
  }
  while (roles.length < count) roles.push('CITIZEN');
  return roles;
}

/** Server-side only. Returns playerId -> role. */
export function assignRoles(playerIds: string[], rng: Rng): Map<string, Role> {
  const roles = shuffle(rolesForCount(playerIds.length), rng);
  const order = shuffle(playerIds, rng);
  const result = new Map<string, Role>();
  order.forEach((id, i) => result.set(id, roles[i]));
  return result;
}
