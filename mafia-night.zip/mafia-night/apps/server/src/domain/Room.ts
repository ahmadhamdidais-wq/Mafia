import {
  DEFAULT_SETTINGS,
  LIMITS,
  SETTINGS_BOUNDS,
  type ChatMessage,
  type RoomSettings,
} from '@mafia/shared';
import { GameEngine, GameError } from './GameEngine';
import type { Rng } from '../infra/random';

export const AVATARS = ['🎩', '🕶️', '🌹', '🎲', '🃏', '🦉', '🐺', '🦊', '🐍', '🦅', '💼', '🔑', '🎻', '⚜️', '🥀'];

export interface Member {
  id: string;
  name: string;
  avatar: string;
  joinedAt: number;
  ready: boolean;
  connected: boolean;
  disconnectedAt: number | null;
}

const CHAT_HISTORY = 80;

/** A room: membership, host, settings, chat log and (optionally) a running game. */
export class Room {
  readonly members = new Map<string, Member>();
  hostId: string;
  settings: RoomSettings = { ...DEFAULT_SETTINGS };
  engine: GameEngine | null = null;
  gameId: string | null = null;
  chat: ChatMessage[] = [];
  /** Players who left mid-game, kept so the final screen can still name them. */
  readonly departed = new Map<string, { name: string; avatar: string }>();
  lastActivity: number;
  private joinSeq = 0;

  constructor(
    readonly code: string,
    hostId: string,
    readonly createdAt: number,
  ) {
    this.hostId = hostId;
    this.lastActivity = createdAt;
  }

  get phase() {
    return this.engine?.phase ?? 'LOBBY';
  }

  get inGame() {
    return this.engine !== null && this.engine.phase !== 'GAME_OVER';
  }

  connectedMembers(): Member[] {
    return [...this.members.values()].filter((m) => m.connected);
  }

  addMember(id: string, name: string, now: number): Member {
    const existing = this.members.get(id);
    if (existing) {
      existing.name = existing.name || name;
      return existing;
    }
    if (this.inGame) throw new GameError('اللعبة بدأت بالفعل في هذه الغرفة.');
    if (this.members.size >= LIMITS.MAX_PLAYERS) throw new GameError('الغرفة ممتلئة.');
    const taken = [...this.members.values()].some((m) => m.name.toLowerCase() === name.toLowerCase());
    if (taken) throw new GameError('هذا الاسم مستخدم في الغرفة، اختر اسمًا آخر.');
    const used = new Set([...this.members.values()].map((m) => m.avatar));
    const avatar = AVATARS.find((a) => !used.has(a)) ?? AVATARS[this.joinSeq % AVATARS.length];
    const member: Member = {
      id,
      name,
      avatar,
      joinedAt: now + this.joinSeq++ / 1000,
      ready: false,
      connected: false,
      disconnectedAt: now,
    };
    this.members.set(id, member);
    if (!this.members.has(this.hostId)) this.hostId = id;
    return member;
  }

  removeMember(id: string) {
    const m = this.members.get(id);
    if (m && this.engine?.players.has(id)) this.departed.set(id, { name: m.name, avatar: m.avatar });
    this.members.delete(id);
    if (this.hostId === id) this.migrateHost();
  }

  /** Picks the earliest-joined connected member (or anyone) as host. */
  migrateHost(): boolean {
    const candidates = [...this.members.values()].sort((a, b) => a.joinedAt - b.joinedAt);
    const next = candidates.find((m) => m.connected && m.id !== this.hostId) ?? candidates.find((m) => m.id !== this.hostId);
    if (!next) return false;
    this.hostId = next.id;
    return true;
  }

  requireHost(id: string) {
    if (id !== this.hostId) throw new GameError('هذا الإجراء للمضيف فقط.');
  }

  setReady(id: string, ready: boolean) {
    if (this.phase !== 'LOBBY') throw new GameError('هذا الإجراء غير متاح الآن.');
    const m = this.members.get(id);
    if (!m) throw new GameError('لست عضوًا في هذه الغرفة.');
    m.ready = ready;
  }

  updateSettings(id: string, patch: Partial<RoomSettings>) {
    this.requireHost(id);
    if (this.phase !== 'LOBBY') throw new GameError('لا يمكن تغيير الإعدادات أثناء اللعب.');
    const next = { ...this.settings };
    for (const key of ['nightSeconds', 'discussionSeconds', 'votingSeconds'] as const) {
      const v = patch[key];
      if (v === undefined) continue;
      const [min, max] = SETTINGS_BOUNDS[key];
      if (typeof v !== 'number' || !Number.isInteger(v) || v < min || v > max) {
        throw new GameError('قيمة إعداد غير صالحة.');
      }
      next[key] = v;
    }
    if (patch.revealRoleOnDeath !== undefined) {
      if (typeof patch.revealRoleOnDeath !== 'boolean') throw new GameError('قيمة إعداد غير صالحة.');
      next.revealRoleOnDeath = patch.revealRoleOnDeath;
    }
    this.settings = next;
  }

  canStart(): { ok: boolean; reason?: string } {
    const players = this.connectedMembers();
    if (players.length < LIMITS.MIN_PLAYERS)
      return { ok: false, reason: `تحتاج ${LIMITS.MIN_PLAYERS} لاعبين على الأقل.` };
    if (players.length > LIMITS.MAX_PLAYERS) return { ok: false, reason: 'عدد اللاعبين أكبر من المسموح.' };
    const notReady = players.filter((m) => m.id !== this.hostId && !m.ready);
    if (notReady.length) return { ok: false, reason: 'ليس كل اللاعبين جاهزين بعد.' };
    return { ok: true };
  }

  startGame(byId: string, clock: () => number, rng: Rng, opts: { skipReadyCheck?: boolean } = {}): GameEngine {
    this.requireHost(byId);
    if (this.inGame) throw new GameError('اللعبة قيد التشغيل بالفعل.');
    // Players who are gone don't get dealt in.
    for (const m of [...this.members.values()]) if (!m.connected) this.members.delete(m.id);
    if (!opts.skipReadyCheck) {
      const check = this.canStart();
      if (!check.ok) throw new GameError(check.reason!);
    } else if (this.connectedMembers().length < LIMITS.MIN_PLAYERS) {
      throw new GameError(`تحتاج ${LIMITS.MIN_PLAYERS} لاعبين على الأقل.`);
    }
    const ids = this.connectedMembers().map((m) => m.id);
    this.engine = new GameEngine(ids, this.settings, clock, rng);
    this.chat = [];
    this.departed.clear();
    return this.engine;
  }

  backToLobby(byId: string) {
    this.requireHost(byId);
    if (this.inGame) throw new GameError('اللعبة ما زالت قيد التشغيل.');
    this.engine = null;
    this.gameId = null;
    this.chat = [];
    this.departed.clear();
    for (const m of [...this.members.values()]) {
      if (!m.connected) this.members.delete(m.id);
      else m.ready = false;
    }
  }

  pushChat(msg: ChatMessage) {
    this.chat.push(msg);
    if (this.chat.length > CHAT_HISTORY * 3) this.chat.splice(0, this.chat.length - CHAT_HISTORY * 3);
  }
}
