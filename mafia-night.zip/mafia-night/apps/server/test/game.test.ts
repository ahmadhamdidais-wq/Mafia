import { test } from 'node:test';
import assert from 'node:assert/strict';
import type { ChatMessage, GameView, Role } from '@mafia/shared';
import { DEFAULT_SETTINGS } from '@mafia/shared';
import { GameEngine, GameError } from '../src/domain/GameEngine';
import { rolesForCount } from '../src/domain/roles';
import { RoomManager, type Broadcaster } from '../src/services/RoomManager';
import { StatsService } from '../src/services/StatsService';
import { UserService } from '../src/services/UserService';
import { MemoryRepository } from '../src/infra/repositories/MemoryRepository';
import { secureRng } from '../src/infra/random';
import { sanitizeChat, sanitizeName } from '../src/domain/validation';

// ------------------------------------------------------------------ helpers

class FakeClock {
  t = 1_000_000;
  now = () => this.t;
  advance(ms: number) {
    this.t += ms;
  }
}

class CaptureBus implements Broadcaster {
  views = new Map<string, GameView>();
  allViews: { userId: string; view: GameView }[] = [];
  chats = new Map<string, ChatMessage[]>();
  phases: string[] = [];
  kickedIds: string[] = [];
  winners: string[] = [];
  state(_c: string, userId: string, view: GameView) {
    this.views.set(userId, view);
    this.allViews.push({ userId, view });
  }
  phase(_c: string, n: { phase: string }) {
    this.phases.push(n.phase);
  }
  chat(_c: string, userId: string, msg: ChatMessage) {
    this.chats.set(userId, [...(this.chats.get(userId) ?? []), msg]);
  }
  chatHistory() {}
  gameEnd(_c: string, w: string) {
    this.winners.push(w);
  }
  kicked(_c: string, userId: string) {
    this.kickedIds.push(userId);
  }
}

function engineWith(n: number, clock = new FakeClock()) {
  const ids = Array.from({ length: n }, (_, i) => `p${i}`);
  const e = new GameEngine(ids, { ...DEFAULT_SETTINGS }, clock.now, secureRng);
  return { e, ids, clock };
}

function byRole(e: GameEngine, role: Role) {
  return [...e.players.values()].filter((p) => p.role === role && p.alive).map((p) => p.id);
}

function skipToNight(e: GameEngine) {
  for (const id of e.players.keys()) e.ackRole(id);
  assert.equal(e.phase, 'NIGHT');
}

function setupRoom(n: number) {
  const clock = new FakeClock();
  const bus = new CaptureBus();
  const repo = new MemoryRepository();
  const mgr = new RoomManager(repo, bus, new StatsService(repo), clock.now, secureRng, () => {});
  const ids = Array.from({ length: n }, (_, i) => `u${i}`);
  const room = mgr.createRoom(ids[0], 'Ahmad');
  mgr.connect(room.code, ids[0]);
  ids.slice(1).forEach((id, i) => {
    mgr.joinRoom(room.code, id, `Player${i + 1}`);
    mgr.connect(room.code, id);
    mgr.setReady(room.code, id, true);
  });
  return { clock, bus, repo, mgr, ids, code: room.code, room };
}

/** Asserts that no view ever told a player a role they shouldn't know. */
function assertNoLeaks(bus: CaptureBus, roomRoles: () => Map<string, Role>, revealOnDeath: boolean) {
  const roles = roomRoles();
  for (const { userId, view } of bus.allViews) {
    if (view.phase === 'GAME_OVER' || view.phase === 'LOBBY') continue;
    const myRole = roles.get(userId);
    for (const p of view.players) {
      if (p.role === undefined || p.id === userId) continue;
      const allowed = (myRole === 'MAFIA' && roles.get(p.id) === 'MAFIA') || (!p.alive && revealOnDeath);
      assert.ok(allowed, `LEAK: ${userId} (${myRole}) saw role of ${p.id} in ${view.phase}`);
    }
    if (myRole !== 'MAFIA') {
      assert.equal(view.mafiaTeam, undefined, 'non-mafia received mafia team');
      assert.equal(view.night?.mafiaVotes, undefined, 'non-mafia received mafia votes');
    }
    if (myRole !== 'DETECTIVE') assert.equal(view.investigations, undefined, 'non-detective got investigations');
    if (myRole !== 'DOCTOR') assert.equal(view.night?.blockedTargetId, undefined);
    assert.equal(view.finalRoles, undefined, 'final roles before game over');
  }
}

// ------------------------------------------------------------------ roles

test('role distribution matches the table for 5..15 players', () => {
  const count = (r: Role[], x: Role) => r.filter((y) => y === x).length;
  for (let n = 5; n <= 15; n++) {
    const r = rolesForCount(n);
    assert.equal(r.length, n);
    const mafia = n === 5 ? 1 : n <= 10 ? 2 : 3;
    assert.equal(count(r, 'MAFIA'), mafia, `mafia for ${n}`);
    assert.equal(count(r, 'DOCTOR'), 1);
    assert.equal(count(r, 'DETECTIVE'), 1);
  }
  assert.throws(() => rolesForCount(4));
  assert.throws(() => rolesForCount(16));
});

// ------------------------------------------------------------------ engine

test('role reveal advances when everyone acknowledges', () => {
  const { e } = engineWith(6);
  assert.equal(e.phase, 'ROLE_REVEAL');
  skipToNight(e);
  assert.equal(e.round, 1);
});

test('role reveal advances on timeout even if someone never acks', () => {
  const { e, clock } = engineWith(5);
  e.ackRole('p0');
  clock.advance(26_000);
  assert.ok(e.tick());
  assert.equal(e.phase, 'NIGHT');
});

test('mafia kill works; doctor save prevents it and shows a strange night', () => {
  const { e, clock } = engineWith(6);
  skipToNight(e);
  const [m1, m2] = byRole(e, 'MAFIA');
  const doc = byRole(e, 'DOCTOR')[0];
  const victim = byRole(e, 'CITIZEN')[0];
  e.nightAction(m1, victim);
  e.nightAction(m2, victim);
  e.nightAction(doc, victim);
  clock.advance(31_000);
  e.tick();
  assert.equal(e.phase, 'DAY');
  assert.deepEqual(e.lastNight, { victimId: null, strange: true });
  assert.ok(e.players.get(victim)!.alive);
});

test('unprotected victim dies', () => {
  const { e, clock } = engineWith(6);
  skipToNight(e);
  const [m1] = byRole(e, 'MAFIA');
  const victim = byRole(e, 'CITIZEN')[0];
  e.nightAction(m1, victim);
  clock.advance(31_000);
  e.tick();
  assert.equal(e.lastNight?.victimId, victim);
  assert.equal(e.players.get(victim)!.alive, false);
  assert.equal(e.players.get(victim)!.deathCause, 'MAFIA');
});

test('night action validation: no mafia-on-mafia, no double doctor/detective, no dead actors, no citizens', () => {
  const { e } = engineWith(7);
  skipToNight(e);
  const [m1, m2] = byRole(e, 'MAFIA');
  const doc = byRole(e, 'DOCTOR')[0];
  const det = byRole(e, 'DETECTIVE')[0];
  const cit = byRole(e, 'CITIZEN')[0];
  assert.throws(() => e.nightAction(m1, m2), GameError);
  assert.throws(() => e.nightAction(cit, m1), GameError);
  assert.throws(() => e.nightAction(det, det), GameError);
  assert.throws(() => e.nightAction(m1, 'nobody'), GameError);
  e.nightAction(doc, cit);
  assert.throws(() => e.nightAction(doc, m1), /بالفعل/);
  e.nightAction(det, m1);
  assert.throws(() => e.nightAction(det, cit), /بالفعل/);
  // mafia may change their pick before the night ends
  e.nightAction(m1, cit);
  e.nightAction(m1, doc);
});

test('detective result is recorded privately and correctly', () => {
  const { e, clock } = engineWith(6);
  skipToNight(e);
  const det = byRole(e, 'DETECTIVE')[0];
  const m = byRole(e, 'MAFIA')[0];
  e.nightAction(det, m);
  clock.advance(31_000);
  e.tick();
  const inv = e.investigationsOf(det);
  assert.equal(inv.length, 1);
  assert.equal(inv[0].isMafia, true);
  assert.equal(e.investigationsOf(m).length, 0);
});

test('doctor cannot protect same player two nights in a row', () => {
  const { e, clock } = engineWith(8);
  skipToNight(e);
  const doc = byRole(e, 'DOCTOR')[0];
  const cit = byRole(e, 'CITIZEN')[0];
  e.nightAction(doc, cit);
  clock.advance(31_000); e.tick(); // DAY
  clock.advance(9_000); e.tick(); // DISCUSSION
  clock.advance(121_000); e.tick(); // VOTING
  clock.advance(31_000); e.tick(); // RESULT
  clock.advance(9_000); e.tick(); // NIGHT 2
  assert.equal(e.phase, 'NIGHT');
  assert.equal(e.round, 2);
  assert.throws(() => e.nightAction(doc, cit), /ليلتين/);
});

test('voting: one vote each, no self votes, plurality eliminates, ties eliminate nobody', () => {
  const { e, clock } = engineWith(7);
  skipToNight(e);
  clock.advance(31_000); e.tick();
  clock.advance(9_000); e.tick();
  assert.equal(e.phase, 'DISCUSSION');
  for (const p of e.alive()) e.discussionSkip(p.id); // everyone skips -> early voting
  assert.equal(e.phase, 'VOTING');
  const alive = e.alive().map((p) => p.id);
  assert.throws(() => e.castVote(alive[0], alive[0]), GameError);
  e.castVote(alive[0], alive[1]);
  assert.throws(() => e.castVote(alive[0], alive[2]), /بالفعل/);
  e.castVote(alive[2], alive[1]);
  e.castVote(alive[3], alive[1]);
  e.castVote(alive[4], alive[0]);
  e.castVote(alive[1], alive[0]);
  for (const id of alive.slice(5)) e.castVote(id, 'SKIP');
  assert.equal(e.phase, 'RESULT'); // all voted -> resolved early
  assert.equal(e.lastVote?.eliminatedId, alive[1]);
  assert.equal(e.players.get(alive[1])!.deathCause, 'VOTE');
});

test('tie vote eliminates nobody', () => {
  const { e, clock } = engineWith(6);
  skipToNight(e);
  clock.advance(31_000); e.tick();
  clock.advance(9_000); e.tick();
  clock.advance(121_000); e.tick();
  const a = e.alive().map((p) => p.id);
  e.castVote(a[0], a[1]);
  e.castVote(a[1], a[0]);
  clock.advance(31_000); e.tick();
  assert.equal(e.lastVote?.eliminatedId, null);
  assert.equal(e.alive().length, 6);
});

test('dead players cannot act or vote', () => {
  const { e, clock } = engineWith(6);
  skipToNight(e);
  const m = byRole(e, 'MAFIA')[0];
  const victim = byRole(e, 'DETECTIVE')[0];
  e.nightAction(m, victim);
  clock.advance(31_000); e.tick();
  clock.advance(9_000); e.tick();
  clock.advance(121_000); e.tick();
  assert.equal(e.phase, 'VOTING');
  assert.throws(() => e.castVote(victim, m), /الموتى/);
});

test('town wins when last mafia is voted out; mafia wins at parity', () => {
  // Town win
  {
    const { e, clock } = engineWith(5);
    skipToNight(e);
    clock.advance(31_000); e.tick();
    clock.advance(9_000); e.tick();
    clock.advance(121_000); e.tick();
    const m = byRole(e, 'MAFIA')[0];
    for (const p of e.alive()) if (p.id !== m) e.castVote(p.id, m);
    e.castVote(m, 'SKIP');
    assert.equal(e.phase, 'RESULT');
    assert.equal(e.pendingWinner, 'TOWN');
    clock.advance(9_000); e.tick();
    assert.equal(e.phase, 'GAME_OVER');
    assert.equal(e.winner, 'TOWN');
  }
  // Mafia win: 5 players, mafia kills 1 at night (4 alive: 1 mafia, 3 town), town votes out a citizen (3: 1v2), next night kill -> 1v1
  {
    const { e, clock } = engineWith(5);
    skipToNight(e);
    const m = byRole(e, 'MAFIA')[0];
    const town = () => e.alive().filter((p) => p.role !== 'MAFIA').map((p) => p.id);
    e.nightAction(m, town()[0]);
    clock.advance(31_000); e.tick();
    clock.advance(9_000); e.tick();
    clock.advance(121_000); e.tick();
    const t = town();
    for (const p of e.alive()) if (p.id !== t[0]) e.castVote(p.id, t[0]);
    e.castVote(t[0], t[1]);
    clock.advance(9_000); e.tick(); // -> NIGHT 2
    assert.equal(e.phase, 'NIGHT');
    e.nightAction(m, town()[0]);
    clock.advance(31_000); e.tick(); // DAY with pending winner
    assert.equal(e.pendingWinner, 'MAFIA');
    clock.advance(9_000); e.tick();
    assert.equal(e.phase, 'GAME_OVER');
    assert.equal(e.winner, 'MAFIA');
  }
});

test('actions in the wrong phase are rejected (timer cannot be skipped by clients)', () => {
  const { e } = engineWith(5);
  assert.throws(() => e.castVote('p0', 'p1'), GameError);
  assert.throws(() => e.nightAction('p0', 'p1'), GameError);
  assert.throws(() => e.discussionSkip('p0'), GameError);
  assert.equal(e.tick(e.endsAt! - 1), false);
});

// ------------------------------------------------------------------ validation

test('input sanitising', () => {
  assert.equal(sanitizeName('  أحمد  '), 'أحمد');
  assert.equal(sanitizeName('a'), null);
  assert.equal(sanitizeName('x'.repeat(17)), null);
  assert.equal(sanitizeName(42), null);
  assert.equal(sanitizeName('\u202Eevil<b>'), 'evilb');
  assert.equal(sanitizeChat('   '), null);
  assert.equal(sanitizeChat('a'.repeat(1000))!.length, 300);
});

test('guest identity: tokens resolve, hashes stored, bad tokens rejected', async () => {
  const repo = new MemoryRepository();
  const users = new UserService(repo);
  const a = await users.ensure(undefined, 'Omar');
  assert.ok(a.token.length >= 40);
  const again = await users.ensure(a.token, 'Omar2');
  assert.equal(again.id, a.id);
  assert.equal((await users.resolve(a.token))?.name, 'Omar2');
  assert.equal(await users.resolve('short'), null);
  assert.equal(await users.resolve('x'.repeat(40)), null);
});

// ------------------------------------------------------------------ room manager

test('lobby: min players, ready checks, host-only start, capacity, unique names', () => {
  const { mgr, ids, code } = setupRoom(4);
  assert.throws(() => mgr.startGame(code, ids[0]), /5/);
  mgr.joinRoom(code, 'u4', 'Late');
  mgr.connect(code, 'u4');
  assert.throws(() => mgr.startGame(code, ids[0]), /جاهزين/);
  mgr.setReady(code, 'u4', true);
  assert.throws(() => mgr.startGame(code, ids[1]), /للمضيف/);
  assert.throws(() => mgr.joinRoom(code, 'u9', 'late'), /مستخدم/);
  mgr.startGame(code, ids[0]);
  assert.throws(() => mgr.joinRoom(code, 'u10', 'Newbie'), /بدأت/);
});

test('room capacity is 15', () => {
  const { mgr, code } = setupRoom(15);
  assert.throws(() => mgr.joinRoom(code, 'extra', 'Extra'), /ممتلئة/);
});

test('chat channels: mafia chat only reaches mafia, dead chat only the dead, no day chat at night', () => {
  const { mgr, bus, ids, code, room } = setupRoom(7);
  mgr.startGame(code, ids[0]);
  for (const id of ids) mgr.ackRole(code, id);
  const e = room.engine!;
  const mafia = byRole(e, 'MAFIA');
  const town = ids.filter((id) => !mafia.includes(id));
  bus.chats.clear();
  mgr.chat(code, mafia[0], 'MAFIA', 'نقتل مين؟');
  for (const id of town) assert.equal((bus.chats.get(id) ?? []).length, 0, 'town saw mafia chat');
  assert.equal(bus.chats.get(mafia[1])?.length, 1);
  assert.throws(() => mgr.chat(code, town[0], 'MAFIA', 'hi'), GameError);
  assert.throws(() => mgr.chat(code, town[0], 'PUBLIC', 'hi'), GameError);
});

test('full simulated game over Room Manager — no secret ever leaks to the wrong client', () => {
  for (let run = 0; run < 25; run++) {
    const n = 5 + (run % 6);
    const { mgr, bus, ids, code, room, clock } = setupRoom(n);
    if (run % 2) mgr.updateSettings(code, ids[0], { revealRoleOnDeath: false });
    mgr.startGame(code, ids[0]);
    const roles = () => new Map([...room.engine!.players.values()].map((p) => [p.id, p.role]));
    for (const id of ids) mgr.ackRole(code, id);

    let guard = 0;
    while (room.phase !== 'GAME_OVER' && guard++ < 200) {
      const e = room.engine!;
      const alive = e.alive().map((p) => p.id);
      const pickOther = (self: string, filter: (id: string) => boolean = () => true) =>
        alive.filter((id) => id !== self && filter(id))[Math.floor(Math.random() * alive.length) % Math.max(1, alive.filter((id) => id !== self && filter(id)).length)];
      if (room.phase === 'NIGHT') {
        for (const id of alive) {
          const r = e.roleOf(id);
          const t = r === 'MAFIA' ? pickOther(id, (x) => e.roleOf(x) !== 'MAFIA') : pickOther(id);
          if (r !== 'CITIZEN' && t) {
            try { mgr.nightAction(code, id, t); } catch (err) { assert.ok(err instanceof GameError); }
          }
        }
        mgr.chat(code, alive.find((id) => e.roleOf(id) === 'MAFIA')!, 'MAFIA', 'secret');
        clock.advance(31_000);
      } else if (room.phase === 'DISCUSSION') {
        mgr.chat(code, alive[0], 'PUBLIC', 'أنا بريء');
        for (const id of alive) mgr.discussionSkip(code, id);
      } else if (room.phase === 'VOTING') {
        for (const id of alive) {
          const t = Math.random() < 0.2 ? 'SKIP' : pickOther(id);
          mgr.castVote(code, id, t ?? 'SKIP');
        }
      } else {
        clock.advance(10_000);
      }
      mgr.tick();
    }
    assert.equal(room.phase, 'GAME_OVER', 'game did not finish');
    assertNoLeaks(bus, roles, !(run % 2));
    // Game over view reveals everything to everyone
    const final = bus.views.get(ids[0])!;
    assert.ok(final.winner);
    assert.equal(final.finalRoles!.length, n);
    // Town never saw the mafia chat line
    for (const id of ids) {
      if (roles().get(id) === 'MAFIA') continue;
      assert.ok(!(bus.chats.get(id) ?? []).some((m) => m.channel === 'MAFIA'), 'town received mafia chat');
    }
  }
});

test('reconnection: player returning within 60s keeps role and life; after 60s they are removed', () => {
  const { mgr, bus, ids, code, room, clock } = setupRoom(6);
  mgr.startGame(code, ids[0]);
  const role = room.engine!.roleOf(ids[3]);
  mgr.disconnect(code, ids[3]);
  assert.equal(room.members.get(ids[3])!.connected, false);
  clock.advance(40_000);
  mgr.tick();
  mgr.connect(code, ids[3]);
  assert.equal(room.engine!.roleOf(ids[3]), role);
  assert.equal(room.engine!.players.get(ids[3])!.alive, true);
  assert.equal(bus.views.get(ids[3])!.me.role, role);

  mgr.disconnect(code, ids[4]);
  clock.advance(61_000);
  mgr.tick();
  assert.ok(!room.members.has(ids[4]));
  assert.ok(bus.kickedIds.includes(ids[4]));
  assert.equal(room.engine!.players.get(ids[4])!.deathCause, 'LEFT');
});

test('multiple tabs: player stays connected until the last socket closes', () => {
  const { mgr, ids, code, room } = setupRoom(5);
  mgr.connect(code, ids[1]);
  mgr.disconnect(code, ids[1]);
  assert.equal(room.members.get(ids[1])!.connected, true);
  mgr.disconnect(code, ids[1]);
  assert.equal(room.members.get(ids[1])!.connected, false);
});

test('host migration on host disconnect and on host leaving', () => {
  const { mgr, ids, code, room, clock } = setupRoom(6);
  mgr.startGame(code, ids[0]);
  mgr.disconnect(code, ids[0]);
  clock.advance(16_000);
  mgr.tick();
  assert.notEqual(room.hostId, ids[0]);
  assert.ok(room.engine!.phase !== 'GAME_OVER' || room.engine!.winner);
  const newHost = room.hostId;
  mgr.leave(code, newHost);
  assert.notEqual(room.hostId, newHost);
  assert.ok(room.members.has(room.hostId));
});

test('replay deals fresh roles, back to lobby resets ready', () => {
  const { mgr, ids, code, room, clock, repo } = setupRoom(5);
  mgr.startGame(code, ids[0]);
  // force a quick end: everyone votes out the mafia
  for (const id of ids) mgr.ackRole(code, id);
  clock.advance(31_000); mgr.tick();
  clock.advance(9_000); mgr.tick();
  for (const p of room.engine!.alive()) mgr.discussionSkip(code, p.id);
  const e = room.engine!;
  const m = byRole(e, 'MAFIA')[0];
  for (const p of e.alive()) mgr.castVote(code, p.id, p.id === m ? 'SKIP' : m);
  clock.advance(9_000); mgr.tick();
  assert.equal(room.phase, 'GAME_OVER');
  assert.throws(() => mgr.replay(code, ids[1]), /للمضيف/);
  mgr.replay(code, ids[0]);
  assert.equal(room.phase, 'ROLE_REVEAL');
  assert.equal(room.engine!.players.size, 5);
  assert.ok(repo.gameLog.length > 0);
});

test('stats and achievements are recorded at game end', async () => {
  const { mgr, ids, code, room, clock, repo } = setupRoom(5);
  const users = new UserService(repo);
  // register users so profiles exist
  for (const id of ids) await repo.createUser({ id, name: id, tokenHash: `h-${id}` });
  mgr.startGame(code, ids[0]);
  for (const id of ids) mgr.ackRole(code, id);
  const e = room.engine!;
  const doc = byRole(e, 'DOCTOR')[0];
  const det = byRole(e, 'DETECTIVE')[0];
  const m = byRole(e, 'MAFIA')[0];
  const cit = byRole(e, 'CITIZEN')[0];
  mgr.nightAction(code, m, cit);
  mgr.nightAction(code, doc, cit); // save
  mgr.nightAction(code, det, m); // find
  clock.advance(31_000); mgr.tick();
  clock.advance(9_000); mgr.tick();
  for (const p of e.alive()) mgr.discussionSkip(code, p.id);
  for (const p of e.alive()) mgr.castVote(code, p.id, p.id === m ? 'SKIP' : m);
  clock.advance(9_000); mgr.tick();
  assert.equal(room.phase, 'GAME_OVER');
  await new Promise((r) => setTimeout(r, 10));
  const docProfile = await repo.getProfile(doc);
  assert.equal(docProfile!.stats.doctorSaves, 1);
  assert.equal(docProfile!.stats.wins, 1);
  assert.ok(docProfile!.achievements.some((a) => a.key === 'DOCTOR_SAVE'));
  const detProfile = await repo.getProfile(det);
  assert.equal(detProfile!.stats.detectiveFinds, 1);
  assert.equal(detProfile!.stats.detectiveWins, 1);
  const mProfile = await repo.getProfile(m);
  assert.equal(mProfile!.stats.losses, 1);
  assert.ok(detProfile!.xp > mProfile!.xp);
  void users;
});
