# 🎩 MAFIA NIGHT — مين فيكم عم بكذب؟

لعبة مافيا أونلاين جماعية في الوقت الحقيقي. أنشئ غرفة، أرسل الرابط لأصدقائك، وكل واحد يلعب من هاتفه.

**التقنيات:** Next.js 14 · React 18 · TypeScript · Tailwind CSS · Framer Motion · Node.js · Socket.IO · PostgreSQL

---

## التشغيل السريع (على جهازك)

المتطلبات: **Node.js 20 أو أحدث**.

```bash
npm install
cp .env.example .env      # على Windows: copy .env.example .env
npm run dev
```

افتح: **http://localhost:3000**

أمر واحد يشغّل كل شيء: خادم اللعبة (Socket.IO + API) والموقع (Next.js) على نفس المنفذ.

> بدون قاعدة بيانات: احذف سطر `DATABASE_URL` من `.env` وستعمل اللعبة بالكامل من الذاكرة (الإحصائيات تُمسح عند إعادة التشغيل).

### الاختبارات

```bash
npm test
```

24 اختبارًا للمحرك: توزيع الأدوار، الليل/النهار/التصويت، الطبيب والمحقق، شروط الفوز، إعادة الاتصال، انتقال المضيف، عزل قنوات الدردشة، و25 مباراة عشوائية كاملة تتحقق أن أي دور سري لم يُرسل أبدًا للاعب لا يحق له معرفته.

---

## قاعدة البيانات (PostgreSQL)

أسهل طريقة عبر Docker:

```bash
docker compose up -d db
```

ثم في `.env`:

```
DATABASE_URL=postgres://mafia:mafia@localhost:5432/mafia_night
```

الـ migrations تُطبَّق **تلقائيًا** عند تشغيل الخادم. لتطبيقها يدويًا: `npm run db:migrate`.

الجداول: `users`, `rooms`, `room_players`, `games`, `game_players`, `game_events`, `votes`, `achievements`, `player_stats` (الملف: `apps/server/src/infra/db/migrations/001_init.sql`).

---

## النشر على الإنترنت (رابط دائم)

المشروع مصمم ليُنشر **كخدمة واحدة** (اللعبة + الموقع على رابط واحد) مع `Dockerfile` جاهز.

### Railway (الأسهل)
1. ارفع المشروع إلى GitHub.
2. في Railway: **New Project → Deploy from GitHub repo** (سيكتشف الـ Dockerfile تلقائيًا).
3. **New → Database → PostgreSQL**.
4. في متغيرات خدمة اللعبة: `DATABASE_URL` = `${{Postgres.DATABASE_URL}}`.
5. **Settings → Networking → Generate Domain** — هذا رابطك. ضعه أيضًا في `PUBLIC_URL`.

### Render
1. **New → Web Service** من GitHub، Runtime: **Docker**.
2. **New → PostgreSQL** وانسخ *Internal Database URL* إلى `DATABASE_URL`.

> ملاحظة: حالة المباريات الجارية تُحفظ في ذاكرة الخادم (هذا ما يجعلها سريعة)، لذا شغّل **نسخة واحدة** (instance واحد). ‏Free tiers التي تُطفئ الخادم عند الخمول قد تُنهي غرفة مفتوحة.

---

## رابط سريع لأصدقائك الآن (بدون نشر)

شغّل اللعبة على جهازك (`npm run dev`) ثم في نافذة أخرى:

```bash
npx cloudflared tunnel --url http://localhost:3000
```

سيظهر رابط مثل `https://xxxx.trycloudflare.com` — افتحه، أنشئ غرفة، واضغط **نسخ رابط الدعوة** وأرسله. (بديل: `ngrok http 3000`).

إذا كان أصدقاؤك على نفس شبكة الـ Wi-Fi: `http://<IP-جهازك>:3000`.

---

## هيكل المشروع

```
packages/shared/        أنواع وبروتوكول مشترك (بدون أسرار)
apps/server/
  src/domain/           محرك اللعبة: GameEngine (State Machine)، Room، الأدوار، الإسقاط لكل لاعب، سياسة الدردشة
  src/services/         RoomManager (الغرف، المؤقتات، إعادة الاتصال، المضيف)، الإحصائيات، الضيوف
  src/infra/            قاعدة البيانات، migrations، المستودعات، rate limiting
  src/transport/        REST API و Socket.IO
  test/                 الاختبارات
apps/web/
  app/                  الصفحات: الرئيسية، الغرفة، طريقة اللعب، الشخصيات، الملف الشخصي
  components/           GameRoom, Lobby, RoleCard, NightScreen, DayScreen, VotingScreen, VoteResults,
                        GameOver, ChatBox, MafiaChat, DeadChat, Timer, PlayerCard, Settings, AchievementPanel...
  lib/                  useGame (Socket)، الصوت، الترجمة، الجلسة
  messages/ar.ts        كل نصوص الواجهة (أضف en.ts / he.ts بنفس الشكل)
```

## API

| | |
|---|---|
| `POST /api/rooms` | إنشاء غرفة `{name, userToken?}` |
| `POST /api/rooms/join` | الانضمام `{code, name, userToken?}` |
| `GET /api/rooms/:id` | معلومات الغرفة |
| `GET /api/player/:id` | الملف والإحصائيات والإنجازات |
| `GET /api/health` | حالة الخادم |

**Socket events:** `room:join` `room:leave` `player:ready` `game:start` `role:ack` `night:action` `discussion:skip` `vote:cast` `chat:message` `game:replay` `room:lobby` `player:reconnect` ← من اللاعب · `room:state` `game:phase` `chat:message` `game:end` `room:kicked` ← من الخادم.

## الأمان ومكافحة الغش
- الخادم هو المصدر الوحيد للحقيقة: الأدوار، أفعال الليل، التصويت، المؤقتات، الفوز.
- كل لاعب يستلم **نسخة خاصة به** من حالة اللعبة (`projection.ts`) — الأدوار ونتائج المحقق ودردشة المافيا لا تغادر الخادم أبدًا إلا لأصحابها.
- تصويت واحد نهائي لكل لاعب، اختيار واحد للطبيب والمحقق كل ليلة، رفض أي فعل في المرحلة الخطأ أو من لاعب ميت.
- المؤقتات Deadline على الخادم؛ العميل يعرضها فقط.
- Rate limiting على الـ API والـ Socket، تنقية الأسماء والرسائل، رموز ضيوف عشوائية آمنة تُخزَّن مشفرة (SHA-256).

## ما تم تنفيذه
- الصفحة الرئيسية السينمائية، إنشاء/انضمام غرفة برمز عشوائي (مثل `M7K92`) ورابط دعوة مع نسخ ومشاركة.
- اللوبي: صور رمزية، جاهز/غير جاهز، بدء للمضيف فقط، 5–15 لاعبًا، إعدادات (مدة الليل/النقاش/التصويت، كشف الدور عند الموت).
- الأدوار: مافيا، مواطن، طبيب، محقق — توزيع سري على الخادم حسب الجدول (`roles.ts`).
- بطاقة الدور (Card Flip) + «فهمت»، الليل (قتل/حماية/تحقيق) مع دردشة المافيا، الصباح («لقد وجدنا جثة...» / «حدث شيء غريب الليلة...»)، النقاش مع زر تخطٍّ، تصويت سري ونتائج متحركة، شروط الفوز، شاشة نهاية تكشف كل الأدوار، العب مرة أخرى / العودة للغرفة.
- الموتى: مشاهدة + دردشة موتى منفصلة.
- إعادة الاتصال خلال 60 ثانية، دعم أكثر من تبويب، انتقال المضيف تلقائيًا.
- الملف الشخصي: إحصائيات + XP + مستويات + الإنجازات الخمسة.
- أصوات مولّدة (ليل، نبض، تصويت، قتل، كشف، فوز، خسارة) مع زر كتم.

## ميزات لاحقة
- أدوار: الحارس الشخصي، المهرج (Jester)، الصياد (Hunter) — أضفها في `roles.ts` و`GameEngine.ts`.
- Voice Chat عبر WebRTC: سياسة القنوات جاهزة في `chatPolicy.ts → voiceChannelFor()`؛ يبقى إضافة signaling عبر Socket.IO وخادم TURN.
- الإنجليزية والعبرية: أنشئ `messages/en.ts` و`messages/he.ts`.
- عدة نسخ من الخادم: Redis adapter لـ Socket.IO ونقل حالة الغرف إلى Redis.
- حسابات دائمة (بريد/Google)، غرف عامة، أحداث متقدمة، سجل المباريات.
